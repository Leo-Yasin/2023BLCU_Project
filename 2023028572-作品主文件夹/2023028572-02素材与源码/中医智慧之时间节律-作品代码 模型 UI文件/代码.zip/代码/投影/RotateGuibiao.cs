using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

public class RotateGuibiao : MonoBehaviour
{
    // Start is called before the first frame update
    public float rotateSpeed = 0.2f;
    private float rotateSum = 4f;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        rotateSum += rotateSpeed;
        this.transform.localEulerAngles = new Vector3(rotateSum, 180, 0);
        if (rotateSum <= 2.6f || rotateSum >= 53f)
        {
            rotateSpeed = -rotateSpeed;
        }
        
    }
}
