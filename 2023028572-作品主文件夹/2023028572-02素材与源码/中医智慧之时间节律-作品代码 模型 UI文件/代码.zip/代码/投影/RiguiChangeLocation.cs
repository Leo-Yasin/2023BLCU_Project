using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using UnityEngine;

public class RiguiChangeLocation : MonoBehaviour
{

    // Start is called before the first frame update
    void Start()
    { 
        Vector3 X = new Vector3(1, 0, 0);
        Vector3 Y = new Vector3(0, 1, 0);
        Vector3 Z = new Vector3(0, 0, 1);

        Vector3 U = new Vector3(Convert.ToSingle(Config.configTest.RVEC["Rigui_R"][0]), Convert.ToSingle(Config.configTest.RVEC["Rigui_R"][3]), Convert.ToSingle(Config.configTest.RVEC["Rigui_R"][6]));
        Vector3 V = new Vector3(Convert.ToSingle(Config.configTest.RVEC["Rigui_R"][1]), Convert.ToSingle(Config.configTest.RVEC["Rigui_R"][4]), Convert.ToSingle(Config.configTest.RVEC["Rigui_R"][7]));
        Vector3 W = new Vector3(Convert.ToSingle(Config.configTest.RVEC["Rigui_R"][2]), Convert.ToSingle(Config.configTest.RVEC["Rigui_R"][5]), Convert.ToSingle(Config.configTest.RVEC["Rigui_R"][8]));
        
        //将Z轴转至W轴
        Vector3 axis_1 = Vector3.Cross(Z, W);
        axis_1.Normalize();

        float cosT = Vector3.Dot(Z, W);
        float theta_1 = Mathf.Acos(cosT);
        float sinT = Mathf.Sin(theta_1);

        float u = X.x;
        float v = X.y;
        float w = X.z;
        float xx = axis_1.x;
        float yy = axis_1.y;
        float zz = axis_1.z;

        //此后X轴变为XX
        Vector3 XX = new Vector3(0, 0, 0);
        XX.x = u * cosT + (yy * w - zz * v) * sinT + xx * (xx * u + yy * v + zz * w) * (1 - cosT);
        XX.y = v * cosT + (zz * u - xx * w) * sinT + yy * (xx * u + yy * v + zz * w) * (1 - cosT);
        XX.z = w * cosT + (xx * v - yy * u) * sinT + zz * (xx * u + yy * v + zz * w) * (1 - cosT);

        Vector3 axis_2 = Vector3.Cross(XX, U);
        axis_2.Normalize();
        axis_2.y = -axis_2.y;
        axis_1.y = -axis_1.y;

        float theta_2 = Mathf.Acos(Vector3.Dot(XX, U));
        //this.transform.rotation = Quaternion.identity;
        //Debug.Log("theta1 " + (float)(theta_1 * 180 / Mathf.PI));
        //Debug.Log("theta2 " + (float)(theta_2 * 180 / Mathf.PI));

        //this.transform.Rotate(new Vector3(0, 1, 0), 45.0f,Space.World);
        this.transform.Rotate(axis_1, -(float)(theta_1 * 180 / Mathf.PI), Space.World);
        this.transform.Rotate(axis_2, -(float)(theta_2 * 180 / Mathf.PI), Space.World);
        this.transform.position = new Vector3( (Convert.ToSingle(Config.configTest.TVEC["Rigui_T"][0]) / 10),
                                                -(Convert.ToSingle(Config.configTest.TVEC["Rigui_T"][1]) / 10),
                                                (Convert.ToSingle(Config.configTest.TVEC["Rigui_T"][2]) / 10));
    }

    // Update is called once per frame
    void Update()
    {

    }
}
