using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;

public class Fadeout : MonoBehaviour
{
    public GameObject dragModel;//食物模型
    private Material m_material;
    private float ChangeTimeLength = 5f;  //更改颜色的时间长度/时间间隔
    private int FadeoutFlag;
    private Color tagcolor;
    //public GameObject dragModel;//食物模型
    // Start is called before the first frame update
    void Start()
    {
        m_material = GetComponent<Renderer>().material;
        tagcolor = m_material.color;
        //FadeoutFlag = dragModel.GetComponent<eat>().FadeoutFlag;
    }

    // Update is called once per frame
    void Update()
    {
        if(dragModel != null)
            FadeoutFlag = dragModel.GetComponent<eat>().FadeoutFlag;//实时获取“痰”是否应该消失的标志FadeoutFlag
        if (FadeoutFlag == 1){
            //Debug.Log("yes");
            m_material.DOColor(new Color(tagcolor.r, tagcolor.g, tagcolor.b,0), 4.0f);//痰消失
        }
        //if (FadeoutFlag==0){
        //    m_material.DOColor(new Color(tagcolor.r, tagcolor.g, tagcolor.b,1), 4.0f);//
        //}
    }
}
