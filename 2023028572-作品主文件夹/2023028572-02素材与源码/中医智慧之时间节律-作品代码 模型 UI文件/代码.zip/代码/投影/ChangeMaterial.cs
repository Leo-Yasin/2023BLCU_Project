using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;

public class ChangeMaterial : MonoBehaviour
{
    public 	Material Mat1, Mat2;      // 贴图  1是bad 2是good
    private Material m_material;
    public float flag=0;
    public GameObject foodShiDao;
    private float ChangeTimeLength = 5f;  //更改颜色的时间长度/时间间隔
    private float totalTime = 0;

    // Start is called before the first frame update
    void Start()
    {
        Debug.Log(Mat1.color);
        Debug.Log(Mat2.color);
        m_material= GetComponent<Renderer>().material;
    }


    // Update is called once per frame
    void Update()
    {
        if (foodShiDao.GetComponent<eat>().beginFlag)
        {
            totalTime += Time.deltaTime;
            if (totalTime > 5f && totalTime < 5.1f)
            {
                flag = 1;
            }

            if (flag == 1)
            {
                m_material.DOColor(Mat2.color, 4.0f);//good肺部
            }
        }
        
    }
}
