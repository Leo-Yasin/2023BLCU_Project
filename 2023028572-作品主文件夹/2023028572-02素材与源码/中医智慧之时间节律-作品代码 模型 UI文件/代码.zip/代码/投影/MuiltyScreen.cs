using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MuiltyScreen : MonoBehaviour
{
    void Awake()
    {
        for (int i = 0; i < Display.displays.Length; i++)
        {
            Display.displays[i].Activate();
            if(i==1) Screen.SetResolution(Display.displays[i].renderingWidth, Display.displays[i].renderingHeight, true);
            else Screen.SetResolution(Display.displays[i].renderingWidth, Display.displays[i].renderingHeight, true);
            Debug.Log("��Ļ����:" + Display.displays.Length + " ��Ļ" + i + " " + Display.displays[i].renderingWidth + " " + Display.displays[i].renderingHeight);
        }
        //if (Display.displays.Length > 1)
        //{
        //    Display.displays[0].Activate();
        //    Screen.SetResolution(1920, 1080, true);

        //    Display.displays[1].Activate();
        //    Screen.SetResolution(1920, 1080, true);

        //    Display.displays[2].Activate();
        //    Screen.SetResolution(4096, 768, true);

        //    //Display.displays[2].Activate();
        //    //Screen.SetResolution(3840, 1080, true);
        //}
        
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
