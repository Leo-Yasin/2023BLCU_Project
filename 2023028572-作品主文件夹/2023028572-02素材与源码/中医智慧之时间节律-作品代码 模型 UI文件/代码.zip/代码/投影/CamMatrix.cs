﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CamMatrix : MonoBehaviour
{
    static float a_t, b_t;
    static float a_AD, b_WS;
    float a, b;
    // Start is called before the first frame update
    void Start()
    {
        BeginString();
    }
    void Update()
    {
        //if (Input.GetKey(KeyCode.UpArrow))
        //{
        //    b = b + 0.005f;
        //}
        //else if (Input.GetKey(KeyCode.DownArrow))
        //{
        //    b = b - 0.005f;
        //}
        //else if (Input.GetKey(KeyCode.LeftArrow))
        //{
        //    a = a - 0.005f;
        //}
        //else if (Input.GetKey(KeyCode.RightArrow))
        //{
        //    a = a + 0.005f;
        //}
          
        SetObliqueness(a, b);

    }
    void BeginString()
    {
        a_t = float.Parse(Config.configTest.dic["ProjectorCalib"]["a_t"]);
        b_t = float.Parse(Config.configTest.dic["ProjectorCalib"]["b_t"]);
        a_AD = float.Parse(Config.configTest.dic["adjust"]["a_AD"]);
        b_WS = float.Parse(Config.configTest.dic["adjust"]["b_WS"]);

        a = -(a_t - 1920.0f / 2) / (1920.0f / 2) + a_AD;
        b = (b_t - 1080.0f / 2) / (1080.0f / 2) + b_WS;
    }


    void SetObliqueness(float horizObl, float vertObl)
    {
        Camera cameraTY = GetComponent<Camera>();

        Matrix4x4 mat = cameraTY.projectionMatrix;
        mat[0, 2] = horizObl;
        mat[1, 2] = vertObl;
        cameraTY.projectionMatrix = mat;
        //Camera.main.projectionMatrix = mat;
    }
}
