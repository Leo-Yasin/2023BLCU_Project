using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FoodMove : MonoBehaviour
{
    public float TranslateSpeed = 0.02f;//移动速度
    float TranslateSpeedTime;//移动时间
    public float walk_time = 10f;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        TranslateSpeedTime -= 0.05f;
        transform.Translate(Vector3.forward * TranslateSpeed);
         if (TranslateSpeedTime > walk_time)
         {
             transform.Rotate(0, 180, 0);
             TranslateSpeedTime = 0.1f;
         }
    }
}
