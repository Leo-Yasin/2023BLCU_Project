using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BTXLAnimation : MonoBehaviour
{
    public float Timeout;
    // Start is called before the first frame update
    void Start()
    {
        Timeout = 0;
        //获取材质本来的属性
        this.GetComponent<Renderer>().material.color = new Color(
        this.GetComponent<Renderer>().material.color.r,
        this.GetComponent<Renderer>().material.color.g,
        this.GetComponent<Renderer>().material.color.b, 
        //需要改的就是这个属性：Alpha值
        this.GetComponent<Renderer>().material.color.a);

    }

    // Update is called once per frame
    void Update()
    {
        if (Timeout < 1)
        {
            Timeout = Timeout + Time.deltaTime;
        }
        if (this.GetComponent<Renderer>().material.color.a <= 1)
        {
            this.GetComponent<Renderer>().material.color = new Color(
            this.GetComponent<Renderer>().material.color.r
            , this.GetComponent<Renderer>().material.color.g,
            this.GetComponent<Renderer>().material.color.b,
 
            //减小Alpha值
            gameObject.GetComponent<Renderer>().material.color.a - Timeout / 50);
        }
    }
}
