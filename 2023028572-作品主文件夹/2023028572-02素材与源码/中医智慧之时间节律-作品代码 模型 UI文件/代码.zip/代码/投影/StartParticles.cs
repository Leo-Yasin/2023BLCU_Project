using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StartParticles : MonoBehaviour
{
    public List<ParticleSystem> particles;
    // Start is called before the first frame update
    void Start()
    {
        foreach (var particle in particles)
        {
            Debug.Log(particle.name+" "+ particle.isPlaying);

            particle.Play();
            Debug.Log(particle.name+" "+ particle.isPlaying);

        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
