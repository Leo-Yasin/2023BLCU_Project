﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Numerics;
using System.Text;
using UnityEngine;

public class Config : MonoBehaviour
{
    private string configPath;
    public Dictionary<string, Dictionary<string, string>> dic;
    public Dictionary<string, ArrayList> RVEC;
    public Dictionary<string, ArrayList> TVEC;
    public Dictionary<string, string> objectsPath;

    public static Config configTest;//创建静态对象，此时对象为空
    private void Awake()
    {
        configTest = this;



        // configPath = Path.Combine(Application.dataPath, "C:/Users/Administrator/Desktop/peizhi/ciganxian virtual experiment 525peizhi small/Output/Config.txt");
        configPath = Application.dataPath + "/StreamingAssets" + "/Config.txt";

        if (dic == null)
        {
            dic = new Dictionary<string, Dictionary<string, string>>();
            RVEC = new Dictionary<string, ArrayList>();
            TVEC = new Dictionary<string, ArrayList>();
            objectsPath = new Dictionary<string, string>();
            LoadConfig();
        }
    }
    void LoadConfig()
    {
        objectsPath.Add("packagePanel", "Player/Canvas_player/PackagePanel");
        objectsPath.Add("missionPanel", "Player/Canvas_player/MissionPanel");

        objectsPath.Add("介绍操作", "Display1_操作/Canvas_操作/介绍操作");
        objectsPath.Add("player", "Player");

        string[] lines;
        if (File.Exists(configPath))
        {
            lines = File.ReadAllLines(configPath);
            BuildDic(lines);
        }

    }

    private void BuildDic(string[] lines)
    {
        string mainkey = null;
        string subKey;
        string subValue;
        ArrayList rvec = new ArrayList();
        ArrayList tvec = new ArrayList();

        foreach (var item in lines)
        {
            string line = null;
            line = item.Trim();
            if (!string.IsNullOrEmpty(line))
            {
                if (line.StartsWith("["))
                {
                    rvec = new ArrayList();
                    tvec = new ArrayList();

                    mainkey = line.Substring(1, line.IndexOf("]") - 1);
                    //Debug.Log(mainkey);
                    if (dic.ContainsKey(mainkey) || mainkey == "R" || mainkey == "T")
                    {
                        continue;
                    }
                    dic.Add(mainkey, new Dictionary<string, string>());
                }
                else
                {
                    if (mainkey == "Rigui_R" || mainkey=="Tongren_R" || mainkey == "Guibiao_R")
                    {
                        string[] lineArr = line.Split(new char[1] { ','});
                        for (int j = 0; j < lineArr.Length; j++)
                        {
                            if (lineArr[j] != "")
                            {
                                rvec.Add(Convert.ToDouble(lineArr[j]));
                            }
                        }
                    }
                    else if ( mainkey == "Rigui_T" || mainkey == "Tongren_T" || mainkey == "Guibiao_T")
                    {
                        if (line != "")
                        {
                            tvec.Add(Convert.ToDouble(line));
                        }
                    }
                    else
                    {
                        var configValue = line.Split(new char[] { '=' }, StringSplitOptions.RemoveEmptyEntries);
                        subKey = configValue[0].Trim();
                        subValue = configValue[1].Trim();
                        subValue = subValue.StartsWith("\"") ? subValue.Substring(1) : subValue;
                        dic[mainkey].Add(subKey, subValue);
                    }
                }
            }
            else
            {
                if (mainkey == "Rigui_R" || mainkey == "Tongren_R" || mainkey == "Guibiao_R")
                {
                    RVEC.Add(mainkey, rvec);
                }
                if (mainkey == "Rigui_T" || mainkey == "Tongren_T" || mainkey == "Guibiao_T")
                {
                    TVEC.Add(mainkey, tvec);
                }
            }
        }
        //if (mainkey == "Rigui_R" || mainkey == "Tongren_R")
        //{
        //    RVEC.Add(mainkey, rvec);
        //}
        //if (mainkey == "Rigui_T" || mainkey == "Tongren_T")
        //{
        //    TVEC.Add(mainkey, tvec);
        //}
    }
}
