using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System;

public class SenorData : SingletonMono<SenorData>
{
    //����Ĳ���
    public string SenorMessage;
    //public GameObject Text;
    // Start is called before the first frame update
    void Start()
    {
        SenorMessage = "Null";
    }

    // Update is called once per frame
    void Update()
    {
       // Text.GetComponent<TextMeshProUGUI>().text = Rotation.ToString();
    }
    /*public void Getmessage(string _s)
    {
        int SenorValue = int.Parse(_s);
        if (Mathf.Abs(SenorValue - Rotation)<=5)
        {
            Debug.Log("xxx");
            return;
        }
        Rotation = SenorValue;
    }*/
}
