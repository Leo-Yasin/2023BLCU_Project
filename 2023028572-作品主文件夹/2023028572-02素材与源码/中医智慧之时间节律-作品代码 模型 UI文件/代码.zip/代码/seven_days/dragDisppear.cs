using DG.Tweening;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class dragDisppear : MonoBehaviour
{

    //��Ҫ����Ĳ��ʣ����ʵ�Surface Type����ҪΪTransprent��
    public Material FadeMat;
    //���ʵ�͸����
    public float alphaValue = 1;

    // Start is called before the first frame update
    void Start()
    {
        ChangeAplhaValue(false, 0);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.F))
        {
            ChangeAplhaValue(true, 3);
        }

        if (Input.GetKeyDown(KeyCode.R))
        {
            ChangeAplhaValue(false, 3);
        }

        FadeMat.SetColor("_BaseColor", new Color(1, 1, 1, alphaValue));

    }

    public void ChangeAplhaValue(bool isChange, float delayTime)
    {
        Tween tween;
        if (isChange)
        {
            tween = DOTween.To(() => alphaValue, x => alphaValue = x, 0.2f, delayTime).OnComplete(() =>
            {
                Debug.Log("͸�����");
            });
        }
        else
        {
            tween = DOTween.To(() => alphaValue, x => alphaValue = x, 1, delayTime).OnComplete(() =>
            {
                Debug.Log("�ָ����");
            });
        }
    }

    void ResetMaterialAlpha(Material material)
    {
        material.SetColor("_BaseColor", new Color(1, 1, 1, 1));
    }
    private void OnDisable()
    {
        ResetMaterialAlpha(FadeMat);
    }
}
