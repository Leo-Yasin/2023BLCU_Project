using DG.Tweening;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
public class test1 : MonoBehaviour
{
    public GameObject model;
    FadeModel fadeModel;

    private Color tagcolor = new Color(1.0f, 1.0f, 1.0f, 0f);
    private GameObject buttonObj;//��ȡ��ť����
    private int flag = 0;//�жϰ�ť�Ƿ���
    // Use this for initialization
    void Start()
    {

        //fadeModel = new FadeModel(model);
        //fadeModel.HideModel();
        //buttonObj = GameObject.Find("Button1");

       //GetComponent<Renderer>().material.DOColor(new Color(tagcolor.r, tagcolor.g, tagcolor.b, 0), 2f);
        
    }
    private void Update()
    {
        
        //buttonObj.GetComponent<Button>().onClick.AddListener(M);
        
        
    }

    public void M()
    {
        GetComponent<Renderer>().material.DOColor(new Color(tagcolor.r, tagcolor.g, tagcolor.b, 0), 0.5f);
    }
    
    
}