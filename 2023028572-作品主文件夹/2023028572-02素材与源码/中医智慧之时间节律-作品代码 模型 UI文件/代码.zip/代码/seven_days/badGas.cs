using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;

public class badGas : MonoBehaviour
{

    public GameObject obj;

    private GameObject gasnumber;

    private int change = 0;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        var gasNumber = obj.GetComponent<ParticleSystem>().emission;

        if (change == 1)
        {
            gasNumber.rateOverTime = 100;
        }
        if (change == 2)
        {
            gasNumber.rateOverTime = 80;
        }
        if (change == 3)
        {
            gasNumber.rateOverTime = 50;
        }
        if (change == 4)
        {
            gasNumber.rateOverTime = 30;
        }
        if (change == 5)
        {
            gasNumber.rateOverTime = 20;
        }
        if (change == 6)
        {
            gasNumber.rateOverTime = 5;
        }
        if (change == 7)
        {
            gasNumber.rateOverTime = 0;
        }


    }

    public void gas_change1()
    {
        change = 1;
    }
    public void gas_change2()
    {
        change = 2;
    }
    public void gas_change3()
    {
        change = 3;
    }
    public void gas_change4()
    {
        change = 4;
    }
    public void gas_change5()
    {
        change = 5;
    }
    public void gas_change6()
    {
        change = 6;
    }
    public void gas_change7()
    {
        change = 7;
    }

}
