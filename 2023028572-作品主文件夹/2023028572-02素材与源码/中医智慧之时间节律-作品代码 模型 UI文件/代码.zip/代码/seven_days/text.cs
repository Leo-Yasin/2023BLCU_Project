using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class text : MonoBehaviour
{
    public List<Camera> cameras = new List<Camera>();
    public GameObject DAY1;
    public GameObject DAY2;
    public GameObject DAY3;
    public GameObject DAY4;
    public GameObject DAY5;
    public GameObject DAY6;
    public GameObject DAY7;

    public GameObject CON1;
    public GameObject CON2;
    public GameObject CON3;
    public GameObject CON4;
    public GameObject CON5;
    public GameObject CON6;
    public GameObject CON7;


    public GameObject intro;

    private int flag = 0;
    // Start is called before the first frame update
    void Start()
    {
        showCamera(0);
    }

    // Update is called once per frame
    void Update()
    {
        DAY1.SetActive(flag == 1);
        DAY2.SetActive(flag == 2);
        DAY3.SetActive(flag == 3);
        DAY4.SetActive(flag == 4);
        DAY5.SetActive(flag == 5);
        DAY6.SetActive(flag == 6);
        DAY7.SetActive(flag == 7);

        CON1.SetActive(flag == 1);
        CON2.SetActive(flag == 2);
        CON3.SetActive(flag == 3);
        CON4.SetActive(flag == 4);
        CON5.SetActive(flag == 5);
        CON6.SetActive(flag == 6);
        CON7.SetActive(flag == 7);
    }

    public void UpdateUI1()//����UI��ʾ�ķ���
    {
        flag = 1;
        //DAY1.SetActive(flag==1);
        showCamera(flag);

        intro.SetActive(false);
    }
    public void UpdateUI2()//����UI��ʾ�ķ���
    {
        flag = 2;
        showCamera(flag);

        //DAY2.SetActive(flag==2);
    }
    public void UpdateUI3()//����UI��ʾ�ķ���
    {
        flag = 3;
        showCamera(flag);

        //DAY3.SetActive(true);
    }
    public void UpdateUI4()//����UI��ʾ�ķ���
    {
        flag = 4;
        showCamera(flag);

        //DAY4.SetActive(true);
    }
    public void UpdateUI5()//����UI��ʾ�ķ���
    {
        flag = 5;
        showCamera(flag);

        //DAY5.SetActive(true);
    }
    public void UpdateUI6()//����UI��ʾ�ķ���
    {
        flag = 6;
        showCamera(flag);

        //DAY6.SetActive(true);
    }
    public void UpdateUI7()//����UI��ʾ�ķ���
    {
        flag = 7;
        showCamera(flag);
        //DAY7.SetActive(true);
    }

    private void showCamera(int num)
    {
        foreach (Camera cam in cameras)
        {
            cam.gameObject.SetActive(false);
        }
        cameras[num].gameObject.SetActive(true);
        if (cameras[num].GetComponent<ControlCamera>() != null)
        {
            cameras[num].GetComponent<ControlCamera>().ResetCamera();
        }
    }
}