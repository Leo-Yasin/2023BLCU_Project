using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class human_action : MonoBehaviour
{
    private int flag = 0;

    public GameObject human1;
    public GameObject human2;
    public GameObject human3;
    public GameObject human4;
    public GameObject human5;
    public GameObject human6;
    public GameObject human7;
    // Start is called before the first frame update
    void Start()
    {
        
    }
    // Update is called once per frame
    void Update()
    {
        human1.SetActive(flag == 1);
        human2.SetActive(flag == 2);
        human3.SetActive(flag == 3);
        human4.SetActive(flag == 4);
        human5.SetActive(flag == 5);
        human6.SetActive(flag == 6);
        human7.SetActive(flag == 7);
    }

    public void human1_change()
    {
        flag = 1;
        controlHuman(human1);
    }
    public void human2_change()
    {
        flag = 2;
        controlHuman(human2);
    }
    public void human3_change()
    {
        flag = 3;
        controlHuman(human3);
    }
    public void human4_change()
    {
        flag = 4;
        controlHuman(human4);
    }
    public void human5_change()
    {
        flag = 5;
        controlHuman(human5);
    }
    public void human6_change()
    {
        flag = 6;
        controlHuman(human6);
    }
    public void human7_change()
    {
        flag = 7;
        controlHuman(human7);
    }
    private void controlHuman(GameObject human)
    {
        if (human.GetComponent<ControlHuman>() != null)
        {
            if (human.GetComponent<ControlHuman>().enabled == true)
            {
                human.GetComponent<ControlHuman>().moveHuman(flag);
            }
        }
 
    }
}
