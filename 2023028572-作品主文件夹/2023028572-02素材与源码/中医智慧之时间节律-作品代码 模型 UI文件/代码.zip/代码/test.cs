using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using UnityEngine;

public class test:MonoBehaviour
{

    // Start is called before the first frame update
    void Start()
    {
        Vector3 X = new Vector3(1, 0, 0);
        Vector3 Y = new Vector3(0, 1, 0);
        Vector3 Z = new Vector3(0, 0, 1);

        Vector3 U = new Vector3(Convert.ToSingle(Config.configTest.RVEC["Guibiao_R"][0]), Convert.ToSingle(Config.configTest.RVEC["Guibiao_R"][3]), Convert.ToSingle(Config.configTest.RVEC["Guibiao_R"][6]));
        Vector3 V = new Vector3(Convert.ToSingle(Config.configTest.RVEC["Guibiao_R"][1]), Convert.ToSingle(Config.configTest.RVEC["Guibiao_R"][4]), Convert.ToSingle(Config.configTest.RVEC["Guibiao_R"][7]));
        Vector3 W = new Vector3(Convert.ToSingle(Config.configTest.RVEC["Guibiao_R"][2]), Convert.ToSingle(Config.configTest.RVEC["Guibiao_R"][5]), Convert.ToSingle(Config.configTest.RVEC["Guibiao_R"][8])); 
        //Vector3 W = new Vector3(Convert.ToSingle(Config.configTest.RVEC["Guibiao_R"][2]), Convert.ToSingle(Config.configTest.RVEC["Guibiao_R"][5]), Convert.ToSingle(Config.configTest.RVEC["Guibiao_R"][8]));

        
        
        //��Z��ת��W��
        Vector3 axis_1 = Vector3.Cross(Z, W);
        axis_1.Normalize();

        float cosT = Vector3.Dot(Z, W);
        float theta_1 = Mathf.Acos(cosT);
        float sinT = Mathf.Sin(theta_1);

        float sinTheta = Mathf.Sin(theta_1);
        float cosTheta = Mathf.Cos(theta_1);


        float u = X.x;
        float v = X.y;
        float w = X.z;
        float xx = axis_1.x;
        float yy = axis_1.y;
        float zz = axis_1.z;

        //�˺�X���ΪXX
        Vector3 XX = new Vector3(0, 0, 0);
        XX.x = u * cosT + (yy * w - zz * v) * sinT + xx * (xx * u + yy * v + zz * w) * (1 - cosT);
        XX.y = v * cosT + (zz * u - xx * w) * sinT + yy * (xx * u + yy * v + zz * w) * (1 - cosT);

        Vector3 axis_2 = Vector3.Cross(XX, U);
        axis_2.Normalize();
        axis_2.y = -axis_2.y;
        axis_1.y = -axis_1.y;

        float theta_2 = Mathf.Acos(Vector3.Dot(XX, U));
        this.transform.rotation = Quaternion.identity;
        //this.transform.rotation = Quaternion.identity;
        //Debug.Log("theta1 " + (float)(theta_1 * 180 / Mathf.PI));
        //Debug.Log("theta2 " + (float)(theta_2 * 180 / Mathf.PI));

        //this.transform.Rotate(new Vector3(0, 1, 0), 45.0f,Space.World);
        this.transform.Rotate(axis_1, -(float)(theta_1 * 180 / Mathf.PI), Space.World);
        this.transform.Rotate(axis_2, -(float)theta_2 * 180 / Mathf.PI, Space.World);
        this.transform.position = new Vector3((Convert.ToSingle(Config.configTest.TVEC["Guibiao_T"][0]) / 10),
                                                -(Convert.ToSingle(Config.configTest.TVEC["Guibiao_T"][1]) / 10),
                                                (Convert.ToSingle(Config.configTest.TVEC["Guibiao_T"][2]) / 10));
    }

    //this.transform.Rotate(axis_2, -(float)(theta_2 * 180 / Mathf.PI), Space.World);

    // Update is called once per frame
    void Update()
    {

    }
}

//#include <opencv2/core/core.hpp>  
//#include <opencv2/opencv.hpp>
//#include <vector>
//#include < fstream >
//#include <iostream>
//using namespace std;
//using namespace cv;
//
//int main()
//{
//    double camD[9] = { 2251.437298345945, 0, 955.2373097827683,
//                        0, 2245.414400101687, 19.33905077195045,
//                        0, 0, 1};
//    double distCoeffD[5] = { -0.02434346145775438, 0.008086025989959897, 0.00622214917240425, -0.003323705448159746, 0 };
//
//    Mat cameraMatrix = Mat(3, 3, CV_64FC1, camD);
//    Mat distorionMatrix = Mat(5, 1, CV_64FC1, distCoeffD);
//
//    vector<Point2f> imagePoints;
//    imagePoints.push_back(Point2f(880, 322));
//    imagePoints.push_back(Point2f(1046, 316));
//
//    //imagePoints.push_back(Point2f(913, 581));
//    //imagePoints.push_back(Point2f(1017, 575));
//
//    imagePoints.push_back(Point2f(927, 901));
//    imagePoints.push_back(Point2f(1004, 900));
//
//    //imagePoints.push_back(Point2f(802, 569));
//    //imagePoints.push_back(Point2f(1132, 565));
//
//    vector<Point3f> objectPoints;
//    objectPoints.push_back(Point3f(2.26, -19.7, 58.56));
//    objectPoints.push_back(Point3f(2.26, 19.7, 58.56));
//
//    //objectPoints.push_back(Point3f(4.26, -11, -6.84));
//    //objectPoints.push_back(Point3f(4.26, 11, -6.84));
//
//    objectPoints.push_back(Point3f(-1.69, -9.76, -84.63));
//    objectPoints.push_back(Point3f(-1.69, 9.76, -84.63));
//
//    //objectPoints.push_back(Point3f(15.06, -39.1, 1.187));
//    //objectPoints.push_back(Point3f(15.06, 39.1, 1.187));
//    Mat rvec, tvec, rotM;
//    cv::solvePnP(objectPoints, (Mat)imagePoints, cameraMatrix, distorionMatrix, rvec, tvec, false);
//    cv::Rodrigues(rvec, rotM);
//    // rvec Ϊ3*1����
//    // rotM Ϊ3*3����
//
//    ofstream fout;
//    fout.open("C:\\Users\\lab525\\Desktop\\ͶӰ����\\TongrenRT1.txt", ios::out);
//
//    //fout << "[Rigui_R]" << endl << cv::format(rotM, cv::Formatter::FMT_CSV) << endl;
//    //fout << "[Rigui_T]" << endl << cv::format(tvec, cv::Formatter::FMT_CSV) << endl;
//
//    fout << "[Tongren_R]" << endl << cv::format(rotM, cv::Formatter::FMT_CSV) << endl;
//    fout << "[Tongren_T]" << endl << cv::format(tvec, cv::Formatter::FMT_CSV) << endl;
//
//
//    return 0;
//}

//���ɲ���̨
//#include <opencv2/core/core.hpp>  
//#include <opencv2/opencv.hpp>
//#include <vector>
//#include < fstream >
//#include <iostream>
//using namespace std;
//using namespace cv;

//int main()
//{
//    double camD[9] = { 2251.437298345945, 0, 955.2373097827683,
//                        0, 2245.414400101687, 19.33905077195045,
//                        0, 0, 1 };
//    double distCoeffD[5] = { -0.02434346145775438, 0.008086025989959897, 0.00622214917240425, -0.003323705448159746, 0 };

//    Mat cameraMatrix = Mat(3, 3, CV_64FC1, camD);
//    Mat distorionMatrix = Mat(5, 1, CV_64FC1, distCoeffD);

//    vector<Point2f> imagePoints;
//    imagePoints.push_back(Point2f(1048, 257));
//    imagePoints.push_back(Point2f(1246, 255));

//    //imagePoints.push_back(Point2f(1100, 523));
//    //imagePoints.push_back(Point2f(1209, 519));

//    imagePoints.push_back(Point2f(1120, 891));
//    imagePoints.push_back(Point2f(1207, 886));

//    vector<Point3f> objectPoints;
//    objectPoints.push_back(Point3f(-0.565, -22.60, 53.96));
//    objectPoints.push_back(Point3f(-0.565, 22.60, 53.96));

//    //objectPoints.push_back(Point3f(0.915, -12.12, -3.134));
//    //objectPoints.push_back(Point3f(0.915,  12.12, -3.134));

//    objectPoints.push_back(Point3f(-5.153, -10.01, -80.86));
//    objectPoints.push_back(Point3f(-5.153, 10.01, -80.86));

//    //objectPoints.push_back(Point3f(15.06, -39.1, 1.187));
//    //objectPoints.push_back(Point3f(15.06, 39.1, 1.187));
//    Mat rvec, tvec, rotM;
//    cv::solvePnP(objectPoints, (Mat)imagePoints, cameraMatrix, distorionMatrix, rvec, tvec, false);
//    cv::Rodrigues(rvec, rotM);
//    // rvec Ϊ3*1����
//    // rotM Ϊ3*3����

//    ofstream fout;
//    fout.open("C:\\Users\\lab525\\Desktop\\ͶӰ����\\����\\TongrenRT0423.txt", ios::out);

//    fout << "[Tongren_R]" << endl << cv::format(rotM, cv::Formatter::FMT_CSV) << endl;
//    fout << "[Tongren_T]" << endl << cv::format(tvec, cv::Formatter::FMT_CSV) << endl;


//    return 0;
//}