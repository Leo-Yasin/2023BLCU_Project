using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WCAttribute : HoursObjectAttribute
{
    private GameObject player;
    private GameObject mainCamera;
    private GameObject angleMove;


    private Animator animator;
    private bool isSit;
    private Vector3 playerSitTF = new Vector3(21.87f, 4.14f, 102.5f);
    private Vector3 playerSitRT = new Vector3(0, 280, 0);
    private Vector3 cameraSitTF = new Vector3(0.0f, 0.36f, 1.456f);
    private Vector3 cameraSitRT = new Vector3(4.749f, 180f, 0f);

    private Vector3 playerSitTF_Rem;
    private Vector3 playerSitRT_Rem;
    private Vector3 cameraSitTF_Rem;
    private Vector3 cameraSitRT_Rem;

    private int doingTimes = 10;

    private Vector3 diffPlayerTF;
    private Vector3 diffPlayerRT;

    private int diffPlayerTFCount;
    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.Find("Player");
        mainCamera = GameObject.Find("Player/Main Camera");
        angleMove = GameObject.Find("Display1_����/Canvas_����/�������/angleMoveArea");
        animator = player.GetComponent<Animator>();

    }


    public override void onOperate()
    {
        if (animator.GetBool("isWc") == false)
        {
            rememberLocations();
            animator.SetBool("isWc", true);
            angleMove.GetComponent<AngleMove>().stopMove();
            player.GetComponent<PlayerManager>().stopPlayer();
            diffPlayerTF = (playerSitTF - player.transform.position) / doingTimes;
            diffPlayerRT = (playerSitRT - player.transform.eulerAngles) / doingTimes;

            mainCamera.transform.localPosition = cameraSitTF;
            mainCamera.transform.localEulerAngles = cameraSitRT;

            diffPlayerTFCount = 0;
            InvokeRepeating("sitPlayer", 0f, 0.1f);


        }
        else
        {
            animator.SetBool("isWc", false);
            diffPlayerTF = (playerSitTF_Rem - player.transform.localPosition) / doingTimes;
            diffPlayerRT = (playerSitRT_Rem - player.transform.localEulerAngles) / doingTimes;
            diffPlayerTFCount = 0;
            InvokeRepeating("resumePlayer", 0f, 0.5f / doingTimes);
        }
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void sitPlayer()
    {
        diffPlayerTFCount++;
        //Physics.autoSyncTransforms = true;
        player.GetComponent<CharacterController>().Move(diffPlayerTF);
        player.transform.Rotate(diffPlayerRT);

        if (diffPlayerTFCount == doingTimes)
        {
            player.GetComponent<HoursMissionHandler>().disNowMissionOperateTime();
            CancelInvoke();
        }
    }

    public void resumePlayer()
    {
        diffPlayerTFCount++;
        //Physics.autoSyncTransforms = true;
        player.GetComponent<CharacterController>().Move(diffPlayerTF);
        player.transform.Rotate(diffPlayerRT);
        if (diffPlayerTFCount == doingTimes)
        {
            CancelInvoke();
            mainCamera.transform.localPosition = cameraSitTF_Rem;
            mainCamera.transform.localEulerAngles = cameraSitRT_Rem;
            player.GetComponent<PlayerManager>().resumePlayer();
            angleMove.GetComponent<AngleMove>().resumeMove();
        }
    }



    public void rememberLocations()
    {
        playerSitTF_Rem = player.transform.position;
        playerSitRT_Rem = player.transform.eulerAngles;
        cameraSitTF_Rem = mainCamera.transform.localPosition;
        cameraSitRT_Rem = mainCamera.transform.localEulerAngles;
    }
    public void resumeLocations()
    {

    }
}
