using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BedAttribute : HoursObjectAttribute
{
    private GameObject player;
    private GameObject mainCamera;
    private GameObject angleMove;

    private Animator animator;
    private bool isSit;
    private Vector3 playerSitTF = new Vector3(23f, 4.03f, 93f);
    private Vector3 playerSitRT = new Vector3(0, 90, 0);
    private Vector3 cameraSitTF = new Vector3(1.72f, 0.86f, 0f);
    private Vector3 cameraSitRT = new Vector3(10f, -90f, 0f);
    
    private Vector3 playerSitTF_Rem;
    private Vector3 playerSitRT_Rem;
    private Vector3 cameraSitTF_Rem;
    private Vector3 cameraSitRT_Rem;

    private int doingTimes = 10;

    private Vector3 diffPlayerTF;
    private Vector3 diffPlayerRT;

    private int diffPlayerTFCount;
    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.Find("Player");
        mainCamera = GameObject.Find("Player/Main Camera");
        angleMove = GameObject.Find("Display1_����/Canvas_����/�������/angleMoveArea");
        animator = player.GetComponent<Animator>();

        //playerSitTF_Rem = new Vector3(23.80f, 4.03f, 90.51f);
        //playerSitRT_Rem = new Vector3(0f, 0f, 0f);
        //cameraSitTF_Rem = new Vector3(0.01f, 1.46f, -1.17f);
        //cameraSitRT_Rem = new Vector3(34.76f, 0f, 0f);

        playerSitTF_Rem = new Vector3(23f, 4.00f, 93f);
        playerSitRT_Rem = new Vector3(0, 90, 0);
        cameraSitTF_Rem = new Vector3(1.72f, 0.86f, 0f);
        cameraSitRT_Rem = new Vector3(10f, -90f, 0f);
    }


    public override void onOperate()
    {
        if (animator.GetBool("isLie") == false)
        {
            rememberLocations();
            animator.SetBool("isLie", true);
            angleMove.GetComponent<AngleMove>().stopMove();
            player.GetComponent<PlayerManager>().stopPlayer();
            diffPlayerTF = (playerSitTF - player.transform.position) / doingTimes;
            diffPlayerRT = (playerSitRT - player.transform.eulerAngles ) / doingTimes;
            if ((diffPlayerRT * doingTimes).y > 180)
            {
                diffPlayerRT.y = 360 / doingTimes - diffPlayerRT.y;
            }
            else if((diffPlayerRT * doingTimes).y < -180)
            {
                diffPlayerRT.y = 360 / doingTimes + diffPlayerRT.y;
            }

            mainCamera.transform.localPosition = cameraSitTF;
            mainCamera.transform.localEulerAngles = cameraSitRT;

            diffPlayerTFCount = 0;
            InvokeRepeating("sitPlayer", 0f, 0.1f);
        }
        else
        {
            diffPlayerTF = -diffPlayerTF;
            diffPlayerRT = -diffPlayerRT;
            diffPlayerTFCount = 0;
            animator.SetBool("isLie", false);
            InvokeRepeating("resumePlayer", 0f, 0.5f / doingTimes);
        }
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void sitPlayer()
    {
        diffPlayerTFCount++;
        //Physics.autoSyncTransforms = true;
        player.GetComponent<CharacterController>().Move(diffPlayerTF);
        player.transform.Rotate(diffPlayerRT);

        if (diffPlayerTFCount == doingTimes)
        {
            if (player.GetComponent<HoursMissionHandler>().getMissionHour() == HoursMissionTrigger.HoursType.��ʱ || player.GetComponent<HoursMissionHandler>().getMissionHour() == HoursMissionTrigger.HoursType.��ʱ ||
                player.GetComponent<HoursMissionHandler>().getMissionHour() == HoursMissionTrigger.HoursType.��ʱ || player.GetComponent<HoursMissionHandler>().getMissionHour() == HoursMissionTrigger.HoursType.��ʱ || player.GetComponent<HoursMissionHandler>().getMissionHour() == HoursMissionTrigger.HoursType.��ʱ)
            {
                player.GetComponent<HoursMissionHandler>().disNowMissionOperateTime();
            }
            CancelInvoke();
        }
    }

    public void resumePlayer()
    {
        diffPlayerTFCount++;

        if (diffPlayerTFCount<= doingTimes)
        {
            //Physics.autoSyncTransforms = true;
            player.GetComponent<CharacterController>().Move(diffPlayerTF);
            player.transform.Rotate(diffPlayerRT);
        }
        if (diffPlayerTFCount == doingTimes + 10)
        {
            mainCamera.transform.localPosition = cameraSitTF_Rem;
            mainCamera.transform.localEulerAngles = cameraSitRT_Rem;
            player.GetComponent<PlayerManager>().resumePlayer();
            angleMove.GetComponent<AngleMove>().resumeMove();

            if (player.GetComponent<HoursMissionHandler>().getMissionHour() == HoursMissionTrigger.HoursType.îʱ)
            {
                player.GetComponent<HoursMissionHandler>().disNowMissionOperateTime();
            }

            if (player.GetComponent<HoursMissionHandler>().getMissionHour() == HoursMissionTrigger.HoursType.��ʱ || player.GetComponent<HoursMissionHandler>().getMissionHour() == HoursMissionTrigger.HoursType.��ʱ || player.GetComponent<HoursMissionHandler>().getMissionHour() == HoursMissionTrigger.HoursType.��ʱ)
            {
                Debug.Log("�����𴲣�");
                player.GetComponent<HoursMissionHandler>().resetSleep();

            }
            CancelInvoke();

        }
    }



    public void rememberLocations()
    {
        playerSitTF_Rem = player.transform.position;
        playerSitRT_Rem = player.transform.eulerAngles;
        cameraSitTF_Rem = mainCamera.transform.localPosition;
        cameraSitRT_Rem = mainCamera.transform.localEulerAngles;

        //Debug.Log(playerSitTF_Rem);
        //Debug.Log(playerSitRT_Rem);
        //Debug.Log(cameraSitTF_Rem);
        //Debug.Log(cameraSitRT_Rem);
    }
    public void resumeLocations()
    {

    }
}
