using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class ControlHuman : MonoBehaviour
{
    private GameObject player;
    public Vector3 playerSitTF ;
    public Vector3 playerSitRT ;
    public int doingTimes;
    public float delayTime;
    private Vector3 diffPlayerTF;
    private Vector3 diffPlayerRT;
    private int diffPlayerTFCount;
    private Animator animator;

    private int number;

    void Start()
    {
        player = this.gameObject;
        animator = player.GetComponent<Animator>();
    }

    public void moveHuman(int number)
    {
        this.number = number;
        diffPlayerTF = (playerSitTF - player.transform.position) / doingTimes;
        diffPlayerRT = (playerSitRT - player.transform.eulerAngles) / doingTimes;
        if ((diffPlayerRT * doingTimes).y > 180)
        {
            diffPlayerRT.y = 360 / doingTimes - diffPlayerRT.y;
        }
        else if ((diffPlayerRT * doingTimes).y < -180)
        {
            diffPlayerRT.y = 360 / doingTimes + diffPlayerRT.y;
        }

        InvokeRepeating("sitPlayer", delayTime, 0.04f);
    }

    private void sitPlayer()
    {
        //Debug.Log(diffPlayerRT+" "+ player.transform.rotation);
        diffPlayerTFCount++;
        //Physics.autoSyncTransforms = true;
        player.transform.position += diffPlayerTF;
        //player.GetComponent<CharacterController>().Move(diffPlayerTF);
        player.transform.Rotate(diffPlayerRT);
        if (diffPlayerTFCount == doingTimes)
        {
            CancelInvoke();
            if (number == 4)
            {
                animator.SetBool("isSet", true);
            }
        }
    }
}
