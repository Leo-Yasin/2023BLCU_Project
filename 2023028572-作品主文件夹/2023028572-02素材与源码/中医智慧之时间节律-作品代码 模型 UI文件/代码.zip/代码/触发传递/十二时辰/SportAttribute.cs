using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SportAttribute : HoursObjectAttribute
{
    private GameObject player;
    private GameObject mainCamera;
    private GameObject angleMove;


    private Animator animator;
    private Vector3 playerSportTF = new Vector3(32.29f, 4.08f, 62.79f);
    private Vector3 playerSportRT = new Vector3(0f, 90f, 0f);
    private Vector3 cameraSportTF = new Vector3(0f, 0.6f, 1.8f);
    private Vector3 cameraSportRT = new Vector3(0f, 180f, 0f);

    private Vector3 playerSportTF_Rem;
    private Vector3 playerSportRT_Rem;
    private Vector3 cameraSportTF_Rem;
    private Vector3 cameraSportRT_Rem;

    private int doingTimes = 10;

    private Vector3 diffPlayerTF;
    private Vector3 diffPlayerRT;


    private int diffPlayerTFCount;
    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.Find("Player");
        mainCamera = GameObject.Find("Player/Main Camera");
        angleMove = GameObject.Find("Display1_����/Canvas_����/�������/angleMoveArea");
        animator = player.GetComponent<Animator>();

    }


    public override void onOperate()
    {
        if (animator.GetBool("isSport") == false)
        {
            rememberLocations();
            animator.SetBool("isSport", true);
            player.GetComponent<PlayerManager>().stopPlayer();
            angleMove.GetComponent<AngleMove>().stopMove();

            diffPlayerTF = (playerSportTF - player.transform.position) / doingTimes;
            diffPlayerRT = (playerSportRT - player.transform.eulerAngles) / doingTimes;
            Debug.Log("sport" + player.transform.position+" "+ playerSportTF + " " + diffPlayerTF);

            mainCamera.transform.localPosition = cameraSportTF;
            mainCamera.transform.localEulerAngles = cameraSportRT;

            diffPlayerTFCount = 0;
            InvokeRepeating("sportPlayer", 0f, 0.5f / doingTimes);


        }
        else
        {
            animator.SetBool("isSport", false);
            diffPlayerTF = (playerSportTF_Rem - player.transform.position) / doingTimes;
            diffPlayerRT = (playerSportRT_Rem - player.transform.eulerAngles) / doingTimes;


            diffPlayerTFCount = 0;
            InvokeRepeating("resumePlayer", 0f, 0.5f / doingTimes);
        }
    }

    // Update is called once per frame
    void Update()
    {

    }

    private void sportPlayer()
    {
        diffPlayerTFCount++;
        player.GetComponent<CharacterController>().Move(diffPlayerTF);
        player.transform.Rotate(diffPlayerRT);

        Debug.Log("���λ��" + diffPlayerTFCount+" " + player.transform.position);

        if (diffPlayerTFCount == doingTimes)
        {
            player.GetComponent<HoursMissionHandler>().disNowMissionOperateTime();

            CancelInvoke();
        }
    }

    private void resumePlayer()
    {
        diffPlayerTFCount++;
        player.GetComponent<CharacterController>().Move(diffPlayerTF);
        player.transform.Rotate(diffPlayerRT);

        if (diffPlayerTFCount == doingTimes)
        {
            mainCamera.transform.localPosition = cameraSportTF_Rem;
            mainCamera.transform.localEulerAngles = cameraSportRT_Rem;
            player.GetComponent<PlayerManager>().resumePlayer();
            angleMove.GetComponent<AngleMove>().resumeMove();
            CancelInvoke();
        }
    }

    public void rememberLocations()
    {
        playerSportTF_Rem = player.transform.position;
        playerSportRT_Rem = player.transform.eulerAngles;
        cameraSportTF_Rem = mainCamera.transform.localPosition;
        cameraSportRT_Rem = mainCamera.transform.localEulerAngles;
    }
}
