using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class HoursObjectAttribute : MonoBehaviour
{
    // �ӿڳ�Ա
    string collidingObjectType = "HoursObject";
    public abstract void onOperate();
    public string getCollidingObjType()
    {
        return collidingObjectType;
    }
}