using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControlCamera : MonoBehaviour
{
    public Vector3 cameraEndTF;
    public Vector3 cameraEndRT;
    public float rotateSpeed;
    public float transformSpeed;

    private Vector3 cameraStartTF;
    private Vector3 cameraStartRT;
    private bool isStart;
    // Start is called before the first frame update

    private void Awake()
    {
        cameraStartTF = this.transform.localPosition;
        cameraStartRT = this.transform.localEulerAngles;
        Debug.Log(this.transform.position + " " + this.transform.eulerAngles);

        //Debug.Log(cameraStartTF + " "+cameraStartRT);
        isStart = false;
    }

    // Update is called once per frame
    void Update()
    {
        if(isStart == true)
        {
            float step1 = rotateSpeed * Time.deltaTime;

            float step2 = transformSpeed * Time.deltaTime;
            gameObject.transform.localPosition = Vector3.MoveTowards(transform.localPosition, cameraEndTF, step2);
            gameObject.transform.localEulerAngles = Vector3.MoveTowards(transform.localEulerAngles, cameraEndRT, step1);
        }
        
    }
    public void ResetCamera()
    {
        if (!this.GetComponent<ControlCamera>().enabled) return;
        gameObject.transform.localPosition = cameraStartTF;
        gameObject.transform.localEulerAngles = cameraStartRT;
        isStart = true;
    }
}
