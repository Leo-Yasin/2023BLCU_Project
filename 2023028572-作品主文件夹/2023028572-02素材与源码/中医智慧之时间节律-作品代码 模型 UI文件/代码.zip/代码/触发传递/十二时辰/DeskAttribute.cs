﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeskAttribute : HoursObjectAttribute
{
    private GameObject player;
    private GameObject mainCamera;
    private GameObject angleMove;


    private Animator animator;
    private Vector3 playerSitTF = new Vector3(27.41f, 4.0f, 81.3f);
    private Vector3 playerSitRT = new Vector3(0, 180, 0);
    private Vector3 cameraSitTF = new Vector3(0.01170158f, 1.342852f, -1.234581f);
    private Vector3 cameraSitRT = new Vector3(29.202f, -0.139f, -0.003f);

    private Vector3 playerSitTF_Rem;
    private Vector3 playerSitRT_Rem;
    private Vector3 cameraSitTF_Rem;
    private Vector3 cameraSitRT_Rem;

    private int doingTimes = 10;

    private Vector3 diffPlayerTF;
    private Vector3 diffPlayerRT;


    private int diffPlayerTFCount;
    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.Find("Player");
        mainCamera = GameObject.Find("Player/Main Camera");
        angleMove = GameObject.Find("Display1_操作/Canvas_操作/人物操作/angleMoveArea");
        animator = player.GetComponent<Animator>();

    }


    public override void onOperate()
    {
        if (animator.GetBool("isSit") == false)
        {
            rememberLocations();
            animator.SetBool("isSit", true);
            player.GetComponent<PlayerManager>().stopPlayer();
            angleMove.GetComponent<AngleMove>().stopMove();

            diffPlayerTF = (playerSitTF - player.transform.position) / doingTimes;
            diffPlayerRT = (playerSitRT - player.transform.eulerAngles) / doingTimes;

            mainCamera.transform.localPosition = cameraSitTF;
            mainCamera.transform.localEulerAngles = cameraSitRT;

            diffPlayerTFCount = 0;
            InvokeRepeating("sitPlayer", 0f, 0.1f);


        }
        else
        {
            animator.SetBool("isSit", false);
            diffPlayerTF = (playerSitTF_Rem - player.transform.position) / doingTimes;
            diffPlayerRT = (playerSitRT_Rem - player.transform.eulerAngles) / doingTimes;

            
            diffPlayerTFCount = 0;
            InvokeRepeating("resumePlayer", 0f, 0.5f / doingTimes);
        }
    }

    // Update is called once per frame
    void Update()
    {

    }

    private void sitPlayer()
    {
        diffPlayerTFCount++;
        player.GetComponent<CharacterController>().Move(diffPlayerTF);
        player.transform.Rotate(diffPlayerRT);

        if (diffPlayerTFCount == doingTimes)
        {
            player.GetComponent<HoursMissionHandler>().disNowMissionOperateTime();
            CancelInvoke();
        }
    }

    private void resumePlayer()
    {
        diffPlayerTFCount++;
        player.GetComponent<CharacterController>().Move(diffPlayerTF);
        player.transform.Rotate(diffPlayerRT);

        if (diffPlayerTFCount == doingTimes)
        {
            mainCamera.transform.localPosition = cameraSitTF_Rem;
            mainCamera.transform.localEulerAngles = cameraSitRT_Rem;
            player.GetComponent<PlayerManager>().resumePlayer();
            angleMove.GetComponent<AngleMove>().resumeMove();
            CancelInvoke();
        }
    }

    public void rememberLocations()
    {
        playerSitTF_Rem = player.transform.position;
        playerSitRT_Rem = player.transform.eulerAngles;
        cameraSitTF_Rem = mainCamera.transform.localPosition;
        cameraSitRT_Rem = mainCamera.transform.localEulerAngles;
    }
}
