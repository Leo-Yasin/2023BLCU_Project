using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FoodAttributes : MonoBehaviour
{
    public Sprite foodImage;
    public string foodName;
    public int addNum;
    public bool isShow;

    // foodAttributes ���� jiaohuAttributes ���е�����
    private string collidingObjectType;

    private void Start()
    {
        isShow = true;
        collidingObjectType="Food";
    }

    public string getCollidingObjType()
    {
        return collidingObjectType;
    }
    
}
