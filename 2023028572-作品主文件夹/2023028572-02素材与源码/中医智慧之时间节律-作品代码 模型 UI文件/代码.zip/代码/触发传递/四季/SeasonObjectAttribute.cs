using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class SeasonObjectAttribute : MonoBehaviour
{
    string collidingObjectType = "SeasonObject";
    public abstract void onOperate();
    public string getCollidingObjType()
    {
        return collidingObjectType;
    }
}