using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WalkAttribute : SeasonObjectAttribute
{
    private GameObject operateCanvas;
    public GameObject intorCanvans;
    public GameObject intorImage;

    // Start is called before the first frame update
    void Start()
    {
        operateCanvas = GameObject.Find("Display1_����/Canvas_����");
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public override void onOperate()
    {

        intorCanvans.SetActive(true);
        intorImage.SetActive(true);
        foreach (Transform child in operateCanvas.transform)
        {
            child.gameObject.SetActive(false);
        }
        // ��ʾ���ܲ���
        intorCanvans.SetActive(true);
    }

    
}
