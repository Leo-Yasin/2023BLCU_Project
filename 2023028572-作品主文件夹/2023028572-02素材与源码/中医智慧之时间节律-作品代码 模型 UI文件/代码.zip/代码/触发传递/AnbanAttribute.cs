using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;

public class AnbanAttribute : MonoBehaviour
{
    // foodAttributes ���� jiaohuAttributes ���е�����
    private string collidingObjectType;

    public GameObject particles;
    public int waiteSeconds;
    // ��ƷԤ������ֵ䣬��ͨ����Ʒ���࣬�鵽��Ӧ����Ʒ��Ϸ����
    public Dictionary<IntroductionAttribute.SeasonsType, GameObject> panelPrefabDict;

    [System.Serializable]
    public struct PanelPrefab
    {
        public IntroductionAttribute.SeasonsType type;
        public GameObject prefab;
    }

    public PanelPrefab[] panelPrefabs;

    private void Start()
    {
        collidingObjectType = "Anban";

        // �ֵ�����
        panelPrefabDict = new Dictionary<IntroductionAttribute.SeasonsType, GameObject>();
        for (int i = 0; i < panelPrefabs.Length; i++)
        {
            if (!panelPrefabDict.ContainsKey(panelPrefabs[i].type))
            {
                panelPrefabDict.Add(panelPrefabs[i].type, panelPrefabs[i].prefab);
            }
        }
    }


    public string getCollidingObjType()
    {
        return collidingObjectType;
    }

    public void aaha()
    {

    }

    public void startFoodParticles()
    {

        StartCoroutine(WaitForSecondsRealtime(waiteSeconds));

    }
    private IEnumerator WaitForSecondsRealtime(float duration)
    {
        Debug.Log("haha "+duration);

        yield return new WaitForSecondsRealtime(duration);
        Debug.Log(duration);
        particles.SetActive(true);
    }

}
