using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JiaohuBack : MonoBehaviour
{
    public GameObject playerOperation;
    public GameObject operateCanvas;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void onBackBtn()
    {
        foreach (Transform child in operateCanvas.transform)
        {
            child.gameObject.SetActive(false);
        }
        // ��ʾ�������
        playerOperation.SetActive(true);
    }

}
