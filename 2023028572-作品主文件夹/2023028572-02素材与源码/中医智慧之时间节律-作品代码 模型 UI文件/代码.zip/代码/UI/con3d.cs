using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// <summary>
// 脚本挂载新建相机上 —— 新相机Clear Flags清除标记设置为：Solid Color，不然会显示天空盒
// </summary>
public class con3d : MonoBehaviour
{
    // public  Transform pivot;
    // public  Vector3   pivotOffset = Vector3.zero;
    // public  Transform target;
    // public  float     distance       = -10.0f;//模型距离相机的距离
    // public  float     minDistance    = -2f;//最小距离
    // public  float     maxDistance    = -15f;//最大距离
    // public  float     zoomSpeed      = 1f;
    // public  float     xSpeed         = 50.0f; //X轴方向的旋转速度
    // public  float     ySpeed         = 50.0f; //Y轴方向的旋转速度
    // public  bool      allowYTilt     = true;//是否允许Y轴倾斜
    // public  float     yMinLimit      = -90f; //Y轴最小倾斜角度
    // public  float     yMaxLimit      = 90f; //Y轴最大倾斜角度
    // private float     x              = 0.0f;//X轴坐标
    // private float     y              = 0.0f;//Y轴坐标
    // private float     targetX        = 0f;//目标X轴坐标
    // private float     targetY        = 0f;//目标Y轴坐标
    // public  float     targetDistance = 0f;
    // private float     xVelocity      = 1f;
    // private float     yVelocity      = 1f;
    // private float     zoomVelocity   = 1f;//缩放速度
    // Start is called before the first frame update
    public float foodready ;//药膳出现的flag

    void Start()
    {
     
    }

    // Update is called once per frame
    void Update()
    {
        foodready = GameObject.Find("FoodImage2").GetComponent<Mousecontrolpicture>().foodready;
        //如果鼠标左键按下
        if (foodready == 1 )
        {
            if (Input.GetMouseButton(0))
            {
                float speed = 2.5f;//旋转跟随速度
                float OffsetX = Input.GetAxis("Mouse X");//获取鼠标x轴的偏移量
                float OffsetY = Input.GetAxis("Mouse Y");//获取鼠标y轴的偏移量
                                                         // float OffsetZ = Input.GetAxis("Mouse Z");//获取鼠标y轴的偏移量
                transform.Rotate(new Vector3(OffsetY, -OffsetX, 0) * speed, Space.Self);//旋转物体
            }
        }
    }
    // private static float ClampAngle(float angle, float min, float max)
    // {
    //     if (angle < -360) angle += 360;
    //     if (angle > 360) angle  -= 360;
    //     return Mathf.Clamp(angle, min, max);
    // }
}




