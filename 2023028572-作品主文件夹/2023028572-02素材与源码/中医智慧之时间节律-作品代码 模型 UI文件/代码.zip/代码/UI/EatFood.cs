using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;

public class EatFood : MonoBehaviour, IDragHandler,IPointerUpHandler,IPointerDownHandler
{
    public string foodText;
    public ZhuoziAttribute.FoodName foodName;
    private RectTransform eatArea;
    private GameObject eatText;
    private GameObject zhuoZi;
    private RectTransform rt;
    private Vector3 remenberLocation;

    // Start is called before the first frame update
    void Start()
    {
        rt = GetComponent<RectTransform>();
        eatArea = GameObject.Find("Display1_����/Canvas_3d/��ʳPanel/UI/eatArea").GetComponent<RectTransform>();
        eatText = GameObject.Find("Display1_����/Canvas_3d/��ʳPanel/UI/eatText");
        zhuoZi = GameObject.Find("Scene/ʮ��ʱ��Triggers/zhuozi");
    }

    // Update is called once per frame
    public void OnDrag(PointerEventData eventData)
    {
        Vector3 pos;
        if (RectTransformUtility.ScreenPointToWorldPointInRectangle
        (rt, eventData.position, eventData.pressEventCamera, out pos))
        {
            rt.position = pos;
        }

    }

    public void OnPointerUp(PointerEventData eventData)
    {

        rt.localPosition = remenberLocation;

        if (eventData.position.x >= Screen.width / 2 - eatArea.rect.width/2 && eventData.position.x <= Screen.width / 2 + eatArea.rect.width / 2 &&
            eventData.position.y >= Screen.height / 2 - eatArea.rect.height / 2 && eventData.position.y <= Screen.height / 2 + eatArea.rect.height / 2)
        {
            showEatText(foodText);
            zhuoZi.GetComponent<ZhuoziAttribute>().eatFood(foodName);
        }
        
    }
    private void showEatText(string str)
    {
        CancelInvoke();
        // ������ʾ���ı�
        //Debug.Log(str);
        eatText.GetComponent<TextMeshProUGUI>().text = str;
        eatText.GetComponent<TextMeshProUGUI>().alpha = 1.0f;

        eatText.gameObject.SetActive(true);
        // ����3.0s������
        //playerCanvas.transform.Find("HintPanel").SetActive(false);
        //InvokeRepeating("hideEatText", 3.0f, 0.1f);
    }
    private void hideEatText()
    {
        eatText.GetComponent<TextMeshProUGUI>().alpha -= 0.05f;
        if (eatText.GetComponent<TextMeshProUGUI>().alpha <= 0f)
        {
            eatText.gameObject.SetActive(false);
            CancelInvoke();
        }
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        remenberLocation=rt.localPosition;
    }
}
