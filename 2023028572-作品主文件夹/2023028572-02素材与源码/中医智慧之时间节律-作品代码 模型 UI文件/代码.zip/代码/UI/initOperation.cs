using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class initOperation : MonoBehaviour
{
    public GameObject canvas3d;
    public GameObject operateCanvas;
    public GameObject playerOperate;
    // Start is called before the first frame update
    void Start()
    {
        if(canvas3d != null)
            canvas3d.SetActive(false);
        operateCanvas.SetActive(true);
        foreach (Transform child in operateCanvas.transform)
        {
            child.gameObject.SetActive(false);
        }
        // ��ʾ���ܲ���
        playerOperate.SetActive(true);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
