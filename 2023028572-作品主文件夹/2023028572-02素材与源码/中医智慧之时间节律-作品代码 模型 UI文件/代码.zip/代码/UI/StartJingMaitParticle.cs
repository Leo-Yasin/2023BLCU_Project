using UnityEngine;
using UnityEngine.EventSystems;
using static Unity.VisualScripting.StickyNote;

public class StartJingMaitParticle : MonoBehaviour,IPointerUpHandler, IPointerDownHandler
{
    public TongrenAttribute.ParticleJingMais jingMai;

    private GameObject tongrenTrigger;
    private GameObject player;
    private float massageTime;
    private bool isMassaging;
    private bool isStartedParicle;
    private outline thisOutLine;
    private Color remenberColor;
    private float jianbian = 0;
    private float duration = 2f;
    private bool isRestart;
    private bool canStartMassage;
    Color colorStart = new Color(207f / 255f, 34f / 255f, 34f / 255f);
    Color colorEnd = new Color(46f / 255f, 34f / 255f, 207f / 255f);
    // Start is called before the first frame update
    void Start()
    {
        isRestart = false;
        isMassaging = false;
        isStartedParicle = false;
        canStartMassage = true;
        tongrenTrigger = GameObject.Find("Scene/ʮ��ʱ��Triggers/ͭ��trigger");
        player = GameObject.Find("Player");
        thisOutLine = this.GetComponent<outline>();
        remenberColor = thisOutLine.OutlineColor;
        //this.GetComponent<MeshRenderer>().materials.Length()
    }

    // Update is called once per frame
    void Update()
    {

        shakingTrigger();

        if(isMassaging == true)
        {
            massageTime +=  Time.deltaTime;
            Debug.Log(massageTime);
            if (massageTime >= 2.0f)
            {
                isMassaging=false;
                isStartedParicle = true;
                tongrenTrigger.GetComponent<TongrenAttribute>().startPartic(jingMai);
                thisOutLine.OutlineColor = remenberColor;
                canStartMassage = true;
            }
        }
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        if (player.GetComponent<HoursMissionHandler>().getIstriggeredMission())
        {
            if (isStartedParicle == false)
            {
                isMassaging = true;
            }
        }
        
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        isMassaging=false;
    }

    private void shakingTrigger()
    {
        // �����ǰ��Ҫ��ʾ�ľ���θ������ ����û��Ħǰ��˸Ѩλ
        if(tongrenTrigger.GetComponent<TongrenAttribute>().getParticleJingMai() == jingMai)
        {
            if (tongrenTrigger.GetComponent<TongrenAttribute>().getIsMassaged()==false && canStartMassage==true)
            {
                isStartedParicle = false;
                massageTime = 0;
                isMassaging = false;
                isRestart = false;
                canStartMassage = false;
            }

            if (isRestart == false)
            {
                isRestart = true;
                thisOutLine.enabled = false;
                thisOutLine.enabled = true;


            }
            // �����û��Ħ�꣬��˸��ʾѨλ
            if (isStartedParicle == false)
            {
                float lerp = Mathf.PingPong(Time.time, duration) / duration;
                thisOutLine.OutlineColor = Color.Lerp(colorStart, colorEnd, lerp);
            }
        }
    }

}