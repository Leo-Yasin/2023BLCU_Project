using System.Collections;
using System.Collections.Generic;
using System;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;



public class IntroductionTrigger : MonoBehaviour
{
    public GameObject player;
    public GameObject operateCanvas;

    // �������
    public GameObject introductionOperation;
    public GameObject playerOperation;
    public GameObject introductionPrefab;

    // ��ť
    public GameObject prexButton;
    public GameObject nextButton;
    public GameObject startButton;


    private int nowIndex;
    private List<GameObject> introductionItems;
    private List<IntroductionAttribute.Attribute> introductionList;
    private List<IntroductionAttribute.Mission> missionList;
    private IntroductionAttribute.SeasonsType missionSeason;

    // Start is called before the first frame update
    void Start()
    {
        nowIndex = 0;
        introductionItems = new List<GameObject>();
        introductionList = new List<IntroductionAttribute.Attribute>();
    }

    // Update is called once per frame
    void Update()
    {
        if (nowIndex == introductionItems.Count - 1)
        {
            startButton.SetActive(true);
        }
        else
        {
            startButton.SetActive(false);
        }
    }
    public void initIntroductionList(List<IntroductionAttribute.Attribute> introductionList)
    {
        this.introductionList = introductionList;
    }

    public void initMissionList(List<IntroductionAttribute.Mission> missionList)
    {
        this.missionList = missionList;
    }

    public void initMissionSeason(IntroductionAttribute.SeasonsType missionSeason)
    {
        this.missionSeason = missionSeason;
    }

    // չʾ����ҳ��
    public void showIntroductions()
    {
        // ����canvas��ĵ�һ������Ԫ������
        foreach (Transform child in operateCanvas.transform)
        {
            Debug.Log(child.name);
            child.gameObject.SetActive(false);
        }
        // ��ʾ���ܲ���
        introductionOperation.SetActive(true);

        foreach (IntroductionAttribute.Attribute obj in introductionList)
        {
            GameObject introductionItem = Instantiate(introductionPrefab);
            // ʵ����introductionPrefab���ӵ�introductionPanel��
            introductionItem.transform.SetParent(introductionOperation.transform);
            introductionItem.transform.localPosition = new Vector3(0, 100, 0);
            introductionItem.transform.localScale = new Vector3(1.7f, 1.7f, 1.7f);
            introductionItem.transform.Find("TitleText (TMP)").GetComponent<TextMeshProUGUI>().text = obj.titleText;
            introductionItem.transform.Find("IntroText (TMP)").GetComponent<TextMeshProUGUI>().text = obj.introText;
            introductionItem.SetActive(false);
            introductionItems.Add(introductionItem);
        }
        introductionItems[0].SetActive(true);
        nowIndex = 0;
    }

    public void onNextIntroduction()
    {
        if(nowIndex < introductionItems.Count - 1)
        {
            introductionItems[nowIndex].SetActive(false);
            introductionItems[++nowIndex].SetActive(true);
        }
    }
    public void onPrexIntroduction()
    {
        Debug.Log(nowIndex);
        if (nowIndex > 0)
        {
            introductionItems[nowIndex].SetActive(false);
            introductionItems[--nowIndex].SetActive(true);
        }
    }
    public void onBackBtn()
    {
        resetList();
        foreach (Transform child in operateCanvas.transform)
        {
            child.gameObject.SetActive(false);
        }
        // ��ʾ�������
        playerOperation.SetActive(true);
    }

    // ��ʼ����,����messionList��������ϵͳ messionHandler
    public void onStartBtn()
    {
        MissionHandler missionHandler = player.GetComponent<MissionHandler>();
        missionHandler.updateMissionList(missionList, missionSeason);
        resetList();

        foreach (Transform child in operateCanvas.transform)
        {
            child.gameObject.SetActive(false);
        }
        // ��ʾ�������
        playerOperation.SetActive(true);

    }
    private void resetList()
    {
        foreach (GameObject child in introductionItems)
        {
            GameObject.Destroy(child, 0f);
        }
        nowIndex = 0;
        introductionItems = new List<GameObject>();
        introductionList = new List<IntroductionAttribute.Attribute>();
    }
}
