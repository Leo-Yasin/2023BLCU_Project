using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TogoScene : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void onSeasonClick(){
        SceneManager.LoadScene("四季-春");
        Debug.Log("lichun");
    }
    public void onJieqiClick(){
        SceneManager.LoadScene("节气-秋");
        Debug.Log("节气-秋");
    }
    public void OnWeekClick()
    {
        SceneManager.LoadScene("weekly_rhythm");
    }      
    public void onShichenClick(){
        SceneManager.LoadScene("十二时辰");
    }
}
