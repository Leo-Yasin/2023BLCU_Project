using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using static UpdateScenes;

public class RecycleScroll : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
{
    public GameObject scrollContent;
    public GameObject scrollContainer;
    public GameObject player;

    private List<GameObject> scrollItems;
    private Vector2 downPos, nowPos;

    private float left;
    private float right;
    private float disLR;
    private float offDis;

    private int data;
    private int lastData;
    private int direction;

    private List<GameObject> showingSeasonList = new List<GameObject>();
    // Start is called before the first frame update
    void Start()
    {
        direction = 0;
        offDis = 1200;
        scrollItems = new List<GameObject>();
        for (int i = 0; i < scrollContent.transform.childCount; i++)
        {
            var child = scrollContent.transform.GetChild(i).gameObject;
            scrollItems.Add(child);
        }
        left = scrollItems[0].transform.localPosition.x;
        right = scrollItems[scrollItems.Count-1].transform.localPosition.x;
        disLR=right-left+100;
        moveItems();
        hideFoods();
    }

    // Update is called once per frame
    void Update()
    {
        //��������⣺ҡ�˲ٿ�ͼ�겻�ܷŴ󣻶�ʮ�Ľ����б�����ѭ����������¼����ԣ�
        if (SenorData.Instance.SenorMessage == "NULL") return;
        if(SenorData.Instance.SenorMessage.Substring(0,2) == "X-")
        {
            for (int i = 0; i < scrollItems.Count; i++)
            {
                scrollItems[i].transform.Translate(10 * 1.0f / 960 * 2400, 0, 0);
                moveItems();//
            }
            SenorData.Instance.SenorMessage = "NULL";
        }
        else if(SenorData.Instance.SenorMessage.Substring(0,2) == "X+")
        {
            for (int i = 0; i < scrollItems.Count; i++)
            {
                scrollItems[i].transform.Translate(-10 * 1.0f / 960 * 2400, 0, 0);
                moveItems();
            }
            SenorData.Instance.SenorMessage = "NULL";
        }
        else if (SenorData.Instance.SenorMessage.Substring(0, 2) == "DJ")
        {
            
        }
    }

    public void OnDrag(PointerEventData eventData)
    {
        //if (player.transform.GetComponent<MissionHandler>() != null)
        //{
        //    if (player.transform.GetComponent<MissionHandler>().getIstriggeredMission())
        //        return;
        //}
        nowPos = eventData.position - downPos;//����
        ////scrollContent.transform.Translate(nowPos.x,0,0);

        for (int i = 0; i < scrollItems.Count; i++)
        {
            scrollItems[i].transform.Translate(nowPos.x, 0, 0);//1
        }
        downPos = eventData.position;
        moveItems();
    }

    private void hideFoods()
    {
        foreach (var item in scrollItems)
        {
            string season = item.name;
            for (int i = 0; i < item.transform.childCount; i++)
            {
                var child = item.transform.GetChild(i).gameObject;
                child.transform.gameObject.SetActive(false);
            }
            item.gameObject.transform.Find(season.Substring(3)).gameObject.SetActive(true);
        }
    }

    private void moveItems()
    {
        float[] scale = { 1.6f, 1.2f, 1.1f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f};
        foreach (GameObject obj in scrollItems)
        {
            GameObject beScaledObj = obj.transform.Find(obj.name.Substring(3)).gameObject;
            int scaleIndex = (int)(Math.Abs(obj.transform.localPosition.x) + 50) / 100;          
            if (scaleIndex <= 11)
            {
                if (scaleIndex == 0) showFood(obj);
                if (scaleIndex == 1) hideFood(obj);
                float objScale = scale[scaleIndex];
                beScaledObj.transform.localScale = new Vector3(objScale, objScale, objScale);
            }
            if (obj.transform.localPosition.x <= left)
            {
                obj.transform.localPosition = new Vector3(obj.transform.localPosition.x + disLR, 0, 0);
            }
            else if (obj.transform.localPosition.x > right)
            {
                obj.transform.localPosition = new Vector3(obj.transform.localPosition.x - disLR, 0, 0);
            }
            UIvoice.Instance.VoicePlay();
        }
        //if()
        
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        downPos = eventData.position;

    }
    public void OnPointerUp(PointerEventData eventData)
    {
        direction = 0;
        float minToCenter = 1000f;
        float offx = 1000f;
        for (int i = 0; i < scrollItems.Count; i++)
        {
            if (minToCenter > Math.Abs(scrollItems[i].transform.localPosition.x))
            {

                minToCenter = Math.Abs(scrollItems[i].transform.localPosition.x);
                offx = scrollItems[i].transform.localPosition.x;
            }
        }
        for (int i = 0; i < scrollItems.Count; i++)
        {
            scrollItems[i].transform.localPosition = new Vector3(scrollItems[i].transform.localPosition.x - offx, 0, 0);
        }
        offDis += offx;
    }
    public float getOffDis()
    {
        //Debug.Log(scrollItems[0].transform.localPosition.x);
        return scrollItems[0].transform.localPosition.x;
    }
    public int getDirection()
    {
        return direction;
    }
    public void addShowSeason(GameObject obj)
    {
        showingSeasonList.Add(obj);
    }

    public void showFood(GameObject obj)
    {
        if (showingSeasonList.Contains(obj))
        {
            for (int i = 0; i < obj.transform.childCount; i++)
            {
                var child = obj.transform.GetChild(i).gameObject;
                if (child.name != obj.name.Substring(3))
                {
                    child.transform.gameObject.SetActive(true);
                    Debug.Log(child.transform.localScale);
                    break;
                }     
            }
        }
        //gameObject.gameObject.transform.Find(season.Substring(3)).gameObject.SetActive(false);
    }
    public void hideFood(GameObject obj)
    {
        for (int i = 0; i < obj.transform.childCount; i++)
        {
            var child = obj.transform.GetChild(i).gameObject;
            if(child.name!= obj.name.Substring(3))
            {
                //Debug.Log("���� " + child.name);
                child.transform.gameObject.SetActive(false);
                break;
            }
            
        }
    }
    public bool isContainedSeason(GameObject obj)
    {
        return showingSeasonList.Contains(obj);
    }
}
