using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Foodappears : MonoBehaviour
{
    public GameObject food1;
    public GameObject food2;
    //渐隐动画的flag
    public float food1ready=0;
    public float food2ready=0;
    //渐隐ui
    public float UI_Alpha = 1;             //初始化时让UI显示
    public float alphaSpeed = 2f;          //渐隐渐显的速度
    private CanvasGroup canvasGroup;

    private float Model_UI=0;
    public GameObject BingtangxueliCanvas;//冰糖雪梨的3d模型显示
    public CanvasGroup BingtangxueliCanvasGroup;

    // Start is called before the first frame update
    void Start()
    {
          canvasGroup = this.GetComponent<CanvasGroup>();
          BingtangxueliCanvasGroup = BingtangxueliCanvas.GetComponent<CanvasGroup>();
        //   food1ready = food1.GetComponent<Mousecontrolpicture>().foodready;
        //   food2ready = food2.GetComponent<Mousecontrolpicture>().foodready;
    }

    // Update is called once per frame
    void Update()
    {
        food1ready = food1.GetComponent<Mousecontrolpicture>().foodready;
        food2ready = food2.GetComponent<Mousecontrolpicture>().foodready;
        //控制渐显渐隐动画
        if (canvasGroup == null)
        {
            return;
        }
 
        if (food1ready==1 &&food2ready==1){
            Invoke("UI_FadeOut_Event", 1);//调用延时函数
            Invoke("Model_Appear", 2);
            
        }

        if (UI_Alpha != canvasGroup.alpha)
        {
            canvasGroup.alpha = Mathf.Lerp(canvasGroup.alpha, UI_Alpha, alphaSpeed * Time.deltaTime);
            if (Mathf.Abs(UI_Alpha - canvasGroup.alpha) <= 0.01f)
            {
                canvasGroup.alpha = UI_Alpha;
            }
        }
    }

    //控制是否渐显渐隐
    // public void UI_FadeIn_Event()
    // {
    //     if (food1ready==1 && food2ready==1){
    //         UI_Alpha = 1;
    //         canvasGroup.blocksRaycasts = true;      //可以和该对象交互
    //     }
    // }
    public void UI_FadeOut_Event()
    {
            UI_Alpha = 0;
            canvasGroup.blocksRaycasts = false;     //不可以和该对象交互
    }
    public void Model_Appear()
    {
        Model_UI=1;
        // BingtangxueliCanvasGroup.alpha=1;
        BingtangxueliCanvasGroup.alpha = Mathf.Lerp(BingtangxueliCanvasGroup.alpha, Model_UI, alphaSpeed * Time.deltaTime * 0.5f);
            if (Mathf.Abs(Model_UI - BingtangxueliCanvasGroup.alpha) <= 0.01)
            {
                // isShow = false;
                BingtangxueliCanvasGroup.alpha = Model_UI;
                Model_UI = 0;
            }
        
    }
    
}
