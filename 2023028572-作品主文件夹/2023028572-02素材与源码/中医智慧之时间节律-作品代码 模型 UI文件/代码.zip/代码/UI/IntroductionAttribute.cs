using System.Collections;
using System.Collections.Generic;
using System;
using TMPro;
using UnityEngine;
using UnityEditor;
using UnityEngine.EventSystems;
using UnityEngine.UIElements;

public class IntroductionAttribute : MonoBehaviour, IPointerDownHandler, IPointerUpHandler 
{ 
    private Vector2 pointerDownPos;
    private IntroductionTrigger trigger;
    private RecycleScroll seasonContainer;
    [Serializable]
    public struct Attribute
    {
        public string titleText;
        public string introText;
    }
    public List<Attribute> introductionList = new List<Attribute>();

    public enum SeasonsType
    {
        EMPTY,
        ����, ��ˮ, ����, ����, ����, ����, ����, С��, â��, ����, С��, ����, ����, ����, ��¶, ���, ��¶, ˪��, ����, Сѩ, ��ѩ, ����, С��, ��

    }
    [Serializable]
    public struct Mission 
    {
        public string missionDescribe;
        public Transform missionTransform;
        public string startHint;        // �����������ʾ
        public string endHint;          // ���������������ʾ
        public int operateTime;            //��Ҫ�����Ĵ���
    }
    // ���� (38, 4.00, 40)
    // 
    public SeasonsType missionSeason;      // ����������
    public List<Mission> missionList = new List<Mission>();

    void Start()
    {
        seasonContainer = GameObject.Find("Display1_����/Canvas_����/�������/24����container").GetComponent<RecycleScroll>();
    }
    public void OnPointerDown(PointerEventData eventData)
    {
        //Debug.Log(eventData.position.x + "  " + eventData.position.y);
        pointerDownPos = eventData.position;
    }
    public void OnPointerUp(PointerEventData eventData)
    {
        if (pointerDownPos.x - eventData.position.x > 3 || pointerDownPos.x - eventData.position.x < -3 || pointerDownPos.y - eventData.position.y > 3 || pointerDownPos.y - eventData.position.y < -3)
            return;
        if (Math.Abs(transform.localPosition.x) > 51)
            return;
        showFood();
        //trigger = Instantiate(IntroductionTrigger);
        trigger = GameObject.Find("Display1_����/Canvas_����/���ܲ���").GetComponent<IntroductionTrigger>();
        // trigger����� missonlist ��initIntroductionlist
        trigger.initIntroductionList(introductionList);
        trigger.initMissionList(missionList);
        trigger.initMissionSeason(missionSeason);

        trigger.showIntroductions();
    }
    // Start is called before the first frame update

    public void showFood()
    {
        string season = gameObject.name;
        for (int i = 0; i < gameObject.transform.childCount; i++)
        {
            var child = gameObject.transform.GetChild(i).gameObject;
            if (child.name != gameObject.name.Substring(3))
            {
                Vector3 scaleMuilty = child.transform.localScale * 1.2f;
                child.transform.localScale = scaleMuilty;
                child.transform.gameObject.SetActive(true);
                Debug.Log(child.transform.localScale);
                break;
            }
        }
        if(!seasonContainer.isContainedSeason(gameObject)) seasonContainer.addShowSeason(gameObject);
        Debug.Log("���� " + gameObject.name); 
        //gameObject.gameObject.transform.Find(season.Substring(3)).gameObject.SetActive(false);

    }
}
