using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CyclicRolling : MonoBehaviour
{
    // public Vector3 flag1,flag2;
    public GameObject JieqiImage1;
    public GameObject JieqiImage2;
    public Vector3 ImageStart;
    public Vector3 ImageXunhuan;
    public GameObject ImageSwap;

    // Start is called before the first frame update
    void Start()
    {
        ImageStart = JieqiImage1.transform.position;
        ImageXunhuan = JieqiImage2.transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        // transform.Translate(Vector3.left * Time.deltaTime * 4, Space.World);
        if (JieqiImage2.transform.position.x < ImageStart.x)
        {
            JieqiImage1.transform.position = ImageXunhuan;
            ImageSwap = JieqiImage1;
            JieqiImage1 = JieqiImage2;
            JieqiImage2 = ImageSwap;
        }
    }
}
