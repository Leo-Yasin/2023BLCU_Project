using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Mousecontrolpicture : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
{
    public Transform orignaParent;//作为父节点
    private Vector3 offset;

    [Header("拖拽目标")]
	public GameObject Tuozhuaimubiao;
	[Header("目标位置")]
	public GameObject Mubiaoweizhi;
    public GameObject Mubiaoweizhi1;
    //渐隐动画的flag
    public float foodready = 0;
    

    // Start is called before the first frame update
    void Start()
    {
      
    }
    
    //鼠标拖拽图片
    public void OnBeginDrag(PointerEventData eventData)
    {
        //开始拖拽的时候记录偏移量
        Vector3 v3;
        orignaParent = transform.parent.parent;//确定初始父节点
        transform.SetParent(transform.parent.parent.parent);//改变父节点
        RectTransformUtility.ScreenPointToWorldPointInRectangle(GetComponent<RectTransform>(),
            eventData.position, eventData.enterEventCamera, out v3);
        offset = transform.position - v3;
    }
    public void OnDrag(PointerEventData eventData)
    {
        transform.position = Input.mousePosition + offset;
    }
    public void OnEndDrag(PointerEventData eventData)
    {
        //throw new System.NotImplementedException();
        transform.SetParent(orignaParent);//恢复父节点
    }
   
    void Update()
	{
         //自动吸附
		if (Mathf.Sqrt((Tuozhuaimubiao.transform.position - Mubiaoweizhi.transform.position).magnitude) < 5)
		{
			Tuozhuaimubiao.transform.position = Mubiaoweizhi.transform.position;
		}
        if (Mathf.Sqrt((Tuozhuaimubiao.transform.position - Mubiaoweizhi1.transform.position).magnitude) < 5)
        {
            Tuozhuaimubiao.transform.position = Mubiaoweizhi1.transform.position;
            foodready=1;
        }
        
    }

}
