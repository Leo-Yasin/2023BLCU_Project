using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControlRoll : MonoBehaviour
{
    /// <summary>
	/// 判断是否正在居中
	/// </summary>
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
