using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class walk : MonoBehaviour
{
    public float TranslateSpeed = 0.02f;//����
    float TranslateSpeedTime;//�ƶ�ʱ��
    public float walk_time = 50f;//�ƶ�ʱ������

    private void Start()
    {
        /*TranslateSpeed = 0.01f;//����
        TranslateSpeedTime = 0.1f;//�ƶ�ʱ��
        walk_time = 50f;*/
    }
    private void Update()
    {
        TranslateSpeedTime += 0.1f;

        transform.Translate(Vector3.forward * TranslateSpeed);
        if (TranslateSpeedTime > walk_time)
        {
            transform.Rotate(0, 180, 0);
            TranslateSpeedTime = 0.1f;
        }
        
    }

    /*
    //�ƶ�����
    public float dis;
    //�ƶ��ٶ�
    public float speed;
    //ˮƽ�ƶ�Ϊtrue ��ֱ�ƶ�Ϊfalse
    public bool flag;
    //�ƶ�����
    float dir = 1;
    //��ʼλ��
    float start_x;
    //float start_y;
    float start_z;

    // Start is called before the first frame update
    void Start()
    {
        start_x = transform.position.x;//x�ƶ������
        //start_y = transform.position.y;//y�ƶ������
        start_z = transform.position.z;//z�ƶ������
    }

    // Update is called once per frame
    void Update()
    {
        //�ƶ�
        //��ֱ�ƶ�
        if (flag)
        {
            transform.Translate(Vector3.right * dir * speed * Time.deltaTime);
            if (System.Math.Abs(transform.position.x - start_x) <= 0.1f || System.Math.Abs(transform.position.x - start_x) >= dis)
            {
                dir = -dir;
            }
        }
        //ˮƽ�ƶ�
        else
        {
            transform.Translate(Vector3.forward * dir * speed * Time.deltaTime);
            if (System.Math.Abs(transform.position.z - start_z) <= 0.1f || System.Math.Abs(transform.position.z - start_z) >= dis)
            { 
                dir = -dir; 
            }
        }
    }
    */
}
