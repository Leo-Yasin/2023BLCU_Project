using System.Collections;
using System.Collections.Generic;
using System.Numerics;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.AI;

public class walknpc : MonoBehaviour
{
    public List<Transform> locations;
    private List<UnityEngine.Vector3> locationsVector3 = new List<UnityEngine.Vector3>();
    private NavMeshAgent _Nav;
    private int nowTargetLoctionsIndex = 0;
    private int add = 1;
    void Start()
    {

        foreach (Transform t in locations)
        {
            locationsVector3.Add(t.position);
        }
        _Nav = this.transform.GetComponent<NavMeshAgent>();
        nowTargetLoctionsIndex = 0;
        _Nav.SetDestination(locationsVector3[nowTargetLoctionsIndex]);
    }

    // Update is called once per frame
    void Update()
    {
        double dis = System.Math.Sqrt(System.Math.Pow((this.transform.position.x - locationsVector3[nowTargetLoctionsIndex].x), 2) + System.Math.Pow((this.transform.position.z - locationsVector3[nowTargetLoctionsIndex].z), 2)+ System.Math.Pow((this.transform.position.y - locationsVector3[nowTargetLoctionsIndex].y), 2));
        //Debug.Log(dis);

        if (dis <=1f)
        {
            if (nowTargetLoctionsIndex + add >= locationsVector3.Count || nowTargetLoctionsIndex + add < 0) add = -add;
            nowTargetLoctionsIndex += add;
            _Nav.SetDestination(locationsVector3[nowTargetLoctionsIndex]);
        }
    }

}
