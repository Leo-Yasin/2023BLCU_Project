using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class CollidingObjects : MonoBehaviour
{
    private List<GameObject> beCollidedObjects;
    public static GameObject collidingObject;
    public static string collidingObjectType;

    // Start is called before the first frame update
    void Start()
    {
        beCollidedObjects = new List<GameObject>(GameObject.FindGameObjectsWithTag("BeCollided"));
    }
      
    // Update is called once per frame
    void Update()
    {
    }
    private void OnTriggerEnter(Collider other)
    {
        if (beCollidedObjects.Contains(other.gameObject))
        {
            //Debug.Log("触碰" + other.name);

            if (other.GetComponent<FoodAttributes>())
            {
                collidingObjectType = other.GetComponent<FoodAttributes>().getCollidingObjType();
            }
            else if (other.GetComponent<AnbanAttribute>())
            {
                collidingObjectType = other.GetComponent<AnbanAttribute>().getCollidingObjType();
            }
            else if (other.GetComponent<HoursObjectAttribute>())
            {

                collidingObjectType = other.GetComponent<HoursObjectAttribute>().getCollidingObjType();
                //Debug.Log("碰撞物体类型" + collidingObjectType);
            }
            else if (other.GetComponent<SeasonObjectAttribute>())
            {
                collidingObjectType = other.GetComponent<SeasonObjectAttribute>().getCollidingObjType();

            }
            if (other.GetComponent<outline>() != null) other.GetComponent<outline>().enabled = true;
            collidingObject = other.gameObject;
        }
    }
    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject== collidingObject)
        {
            if (other.GetComponent<outline>() != null) other.GetComponent<outline>().enabled = false;
            collidingObject = null;
            collidingObjectType = "";
        }
    }
}
