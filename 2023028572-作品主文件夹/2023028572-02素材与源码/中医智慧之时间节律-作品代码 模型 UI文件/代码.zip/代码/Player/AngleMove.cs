using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static UnityEngine.Rendering.VirtualTexturing.Debugging;
using UnityEngine.EventSystems;
using System.Drawing;
using Unity.VisualScripting;

public class AngleMove : MonoBehaviour, IPointerDownHandler, IDragHandler
{
    public float rotateSpeed;
    public GameObject myCamera,player;
    public Transform headTF;
    private Vector2 downPos, nowPos;
    private float rotateSpeed_Rem;

    private void Awake()
    {
        if (rotateSpeed == 0) rotateSpeed = 3;
        rotateSpeed_Rem = rotateSpeed;
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        downPos = eventData.position;
        //Debug.Log(downPos.x + " " + downPos.y);
    }

    public void OnDrag(PointerEventData eventData)
    {
        nowPos = eventData.position - downPos;
        //if () ;
        //Debug.Log("aaa" + GetAngle(myCamera.transform, headTF));
        if (GetAngle(myCamera.transform, headTF)>-70 && GetAngle(myCamera.transform, headTF)<40)
            myCamera.transform.RotateAround(headTF.position, myCamera.transform.right, -nowPos.y * rotateSpeed / 10 );
        else if(GetAngle(myCamera.transform, headTF) < -70 && -nowPos.y<0)
            myCamera.transform.RotateAround(headTF.position, myCamera.transform.right, -nowPos.y * rotateSpeed / 10);
        else if (GetAngle(myCamera.transform, headTF) > 40 && -nowPos.y > 0)
            myCamera.transform.RotateAround(headTF.position, myCamera.transform.right, -nowPos.y * rotateSpeed / 10);
        player.transform.Rotate(new Vector3(0, nowPos.x * rotateSpeed * Time.deltaTime*10 , 0));
        downPos = eventData.position;
    }
    private float GetAngle(Transform trs, Transform target)
    {
        Vector3 xiangliang = target.position-trs.position;
        Vector3 pingmian = xiangliang;
        pingmian.y = 0;
        float angle = Vector3.Angle(pingmian, xiangliang);
        if(target.position.y > trs.position.y)
            return angle;
        else
            return -angle;

    }
    private void Update()
    {

    }

    public void stopMove()
    {
        rotateSpeed = 0;
    }

    public void resumeMove()
    {
        rotateSpeed = rotateSpeed_Rem;
    }
}
