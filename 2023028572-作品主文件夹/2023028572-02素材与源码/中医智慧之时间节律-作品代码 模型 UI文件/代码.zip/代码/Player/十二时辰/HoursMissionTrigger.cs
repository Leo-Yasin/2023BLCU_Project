using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class HoursMissionTrigger : MonoBehaviour
{
    
    public GameObject missionIntroductionPrefab;
    public GameObject timeController;
    // �������
    public GameObject player;
    public GameObject operateCanvas;
    public GameObject introductionOperation;
    public GameObject playerOperation;

    // ��ť
    public GameObject prexButton;
    public GameObject nextButton;
    public GameObject startButton;

    // ��ǰ����
    private HoursType nowHour;
    private List<HoursMissionAttribute> nowHourMissions;
    private List<HoursMissionIntroductionAttribute> nowHourIntroductions;
    private int nowIntroductionIndex;

    private List<GameObject> introductionItems;
    private DateTime dateTime;
    public enum HoursType
    {
        ��ʱ,
        ��ʱ,
        îʱ,
        ��ʱ,
        ��ʱ,
        ��ʱ,
        δʱ,
        ��ʱ,
        ��ʱ,
        ��ʱ,
        ��ʱ,
        ��ʱ,
        ��
    }

    [Serializable]
    public class HoursMissionIntroductionAttribute
    {
        public string titleText;
        public string introText;
    }

    [Serializable]
    public class HoursMissionAttribute 
    {
        public string missionDescribe;
        public Transform missionTransform;
        public string startHint;        // �����������ʾ
        public string endHint;          // ���������������ʾ
        public int operateTime;
    }

    [Serializable]
    public struct HourMission
    {
        public HoursType hour;
        public List<HoursMissionAttribute> missionAttributes;
        public List<HoursMissionIntroductionAttribute> missionIntroductions;
    }

    public HourMission[] hoursMissionList ;

    public Dictionary<HoursType, List<HoursMissionAttribute>> hoursMissionAttributesDic;
    public Dictionary<HoursType, List<HoursMissionIntroductionAttribute>> missionIntroductionsDic;

    private void Start()
    {
        introductionItems = new List<GameObject>();
        // �ֵ�����
        hoursMissionAttributesDic = new Dictionary<HoursType, List<HoursMissionAttribute>>();
        missionIntroductionsDic = new Dictionary<HoursType, List<HoursMissionIntroductionAttribute>>();
        for (int i = 0; i < hoursMissionList.Length; i++)
        {
            if (!hoursMissionAttributesDic.ContainsKey(hoursMissionList[i].hour))
            {
                hoursMissionAttributesDic.Add(hoursMissionList[i].hour, hoursMissionList[i].missionAttributes);
                missionIntroductionsDic.Add(hoursMissionList[i].hour, hoursMissionList[i].missionIntroductions);
            }
        }

    }
    private void Update()
    {
        dateTime = timeController.GetComponent<HoursTimeController>().getCurrentTime();
        HoursType[] hours = {
            HoursType.��ʱ,
            HoursType.��ʱ,
            HoursType.îʱ,
            HoursType.��ʱ,
            HoursType.��ʱ,
            HoursType.��ʱ,
            HoursType.δʱ,
            HoursType.��ʱ,
            HoursType.��ʱ,
            HoursType.��ʱ,
            HoursType.��ʱ,
            HoursType.��ʱ};
        nowHour = hours[(dateTime.Hour + 23) / 2 % 12];
        this.transform.Find("missionText").GetComponent<TextMeshProUGUI>().text = nowHour.ToString();
    }

    public void onTriggerMission()
    {
        //Debug.Log("onTriggerMission" + player.GetComponent<HoursMissionHandler>().isEndMission());
        if(player.GetComponent<HoursMissionHandler>().getIstriggeredMission() == false)
        {
            if (player.GetComponent<HoursMissionHandler>().isEndMission() == false)
            {
                if (hoursMissionAttributesDic.ContainsKey(nowHour))
                {
                    nowHourMissions = hoursMissionAttributesDic[nowHour];
                    nowHourIntroductions = missionIntroductionsDic[nowHour];
                    timeController.GetComponent<HoursTimeController>().stopTimeFlow();
                    showIntroductions(nowHourIntroductions);
                }
            }
            else
            {
                timeController.GetComponent<HoursTimeController>().resumeTimeFlow();
                player.GetComponent<HoursMissionHandler>().resetNowMissionIndex();
                player.GetComponent<HoursMissionHandler>().deleteMissionList();

            }
        }   
        
    }

    private void showIntroductions(List<HoursMissionIntroductionAttribute> introList)
    {
        // ���û������
        if (introList == null)
        {
            return;
        }
        // ����canvas��ĵ�һ������Ԫ������
        foreach (Transform child in operateCanvas.transform)
        {
            //Debug.Log(child.name);
            child.gameObject.SetActive(false);
        }
        // ��ʾ���ܲ���
        introductionOperation.SetActive(true);
        foreach (var intro in introList)
        {
            GameObject introductionItem = Instantiate(missionIntroductionPrefab);
            // ʵ����introductionPrefab���ӵ�introductionPanel��
            introductionItem.transform.parent = introductionOperation.transform;
            introductionItem.transform.localPosition = new Vector3(0, 100, 0);
            introductionItem.transform.localScale = new Vector3(1.7f, 1.7f, 1.7f);
            introductionItem.transform.Find("TitleText (TMP)").GetComponent<TextMeshProUGUI>().text = intro.titleText;
            introductionItem.transform.Find("IntroText (TMP)").GetComponent<TextMeshProUGUI>().text = intro.introText;
            introductionItem.SetActive(false);
            introductionItems.Add(introductionItem);
        }
        introductionItems[0].SetActive(true);

    }
    public void onNextIntroduction()
    {
        if (nowIntroductionIndex < introductionItems.Count - 1)
        {
            introductionItems[nowIntroductionIndex].SetActive(false);
            introductionItems[++nowIntroductionIndex].SetActive(true);
        }
    }
    public void onPrexIntroduction()
    {
        Debug.Log(nowIntroductionIndex);
        if (nowIntroductionIndex > 0)
        {
            introductionItems[nowIntroductionIndex].SetActive(false);
            introductionItems[--nowIntroductionIndex].SetActive(true);
        }
    }
    public void onBackBtn()
    {
        timeController.GetComponent<HoursTimeController>().resumeTimeFlow();
        resetList();
        foreach (Transform child in operateCanvas.transform)
        {
            child.gameObject.SetActive(false);
        }

        // ��ʾ�������
        playerOperation.SetActive(true);
    }

    // ��ʼ����,����messionList��������ϵͳ messionHandler
    public void onStartBtn()
    {
        HoursMissionHandler missionHandler = player.GetComponent<HoursMissionHandler>();
        missionHandler.updateMissionList(nowHourMissions, nowHour);
        resetList();
        foreach (Transform child in operateCanvas.transform)
        {
            child.gameObject.SetActive(false);
        }
        // ��ʾ�������
        playerOperation.SetActive(true);

    }

    private void resetList()
    {
        foreach (GameObject child in introductionItems)
        {
            GameObject.Destroy(child, 0f);
        }
        introductionItems = new List<GameObject>();
    }

}
