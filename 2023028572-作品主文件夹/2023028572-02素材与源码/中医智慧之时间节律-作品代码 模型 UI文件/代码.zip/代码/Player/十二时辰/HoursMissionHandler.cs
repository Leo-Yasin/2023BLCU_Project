using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using TMPro;
using static HoursMissionTrigger;
using System;
using System.Threading;

public class HoursMissionHandler : MonoBehaviour
{
    public GameObject lineRendererObject;
    public GameObject player;
    public GameObject playerCanvas;
    public GameObject missionPrefab;

    private int nowMissionOperateTime; // ��ǰ������Ҫ���м��β���

    private NavMeshAgent _Nav;
    private LineRenderer _LineRenderer;
    private int nowMissionIndex;

    private List<HoursMissionTrigger.HoursMissionAttribute> missionList;
    private List<GameObject> missionTextList;
    private HoursMissionTrigger.HoursType missionHour;
    private bool isEntered; // �Ƿ񵽴����ǰ��������
    private bool isTriggedMission;
    private Vector3 missionLocation;
    // Use this for initialization
    void Start()
    {
        _Nav = player.transform.GetComponent<NavMeshAgent>();
        _LineRenderer = lineRendererObject.transform.GetComponent<LineRenderer>();
        this.missionTextList = new List<GameObject>();
        this.missionList = new List<HoursMissionTrigger.HoursMissionAttribute>();
        isTriggedMission = false;
        nowMissionIndex = -5;
    }

    // Update is called once per frame
    [System.Obsolete]
    void Update()
    {

        // ����������ſ�ʼִ��
        if (isTriggedMission == true)
        {
            updateStage();
            drawLeadArrow(missionLocation);
        }

    }

    // ���������б� ��ɫ
    private void updatePlayerCanvasMissions()
    {
        foreach (GameObject mission in missionTextList)
        {
            mission.GetComponent<TextMeshProUGUI>().color = Color.white;
        }
        missionTextList[nowMissionIndex].GetComponent<TextMeshProUGUI>().color = new Color(1.0f, 0.76f, 0.294f);
    }

    // ���Ƶ�����ͷ
    [System.Obsolete]
    private void drawLeadArrow(Vector3 targetPoint)
    {
        //Debug.Log(targetPoint);
        _Nav.SetDestination(targetPoint);        //NavMeshAgent�Դ��ƶ�����  
        if (_Nav.path.corners.Length > 1)                  //ʱ�̼��·�ߵĵ㣬������1��ʱ�򣬰���Щ�㸳���LineRenderer�����Ƴ�����
        {
            // ���Ƽ�ͷ����
            //Debug.Log(_Nav.path.corners[1]);
            player.transform.Find("Leader").transform.LookAt(_Nav.path.corners[1]);

            //����·��
            //_LineRenderer.SetVertexCount(_Nav.path.corners.Length);
            //int count = 2;
            //Vector3[] road = new Vector3[count];
            //for (int i = 0; i < count; i++)
            //{
            //    road[i] = _Nav.path.corners[i];
            //}
            //_LineRenderer.SetVertexCount(count);
            //_LineRenderer.SetPositions(road);
        }
    }

    // ���������б�������ʼִ������
    public void updateMissionList(List<HoursMissionTrigger.HoursMissionAttribute> missionList, HoursMissionTrigger.HoursType missionHour)
    {
        nowMissionIndex = 0;
        this.missionTextList = new List<GameObject>();
        this.missionList = new List<HoursMissionTrigger.HoursMissionAttribute>(missionList);
        this.missionHour = missionHour;
        missionLocation = missionList[nowMissionIndex].missionTransform.position;

        int index = 0;
        foreach (HoursMissionTrigger.HoursMissionAttribute mission in missionList)
        {
            GameObject missionText = Instantiate(missionPrefab);
            missionTextList.Add(missionText);
            missionText.transform.parent = playerCanvas.transform.Find("MissionPanel");
            missionText.transform.localPosition = new Vector3(0, -50 * index, 0);
            index++;
            missionText.GetComponent<TextMeshProUGUI>().text = mission.missionDescribe;
        }
        missionTextList[nowMissionIndex].GetComponent<TextMeshProUGUI>().color = new Color(1.0f, 0.76f, 0.294f);

        // ��ʼִ������
        isTriggedMission = true;
        isEntered = false;
        player.transform.Find("Leader").gameObject.SetActive(true);
        nowMissionOperateTime = missionList[nowMissionIndex].operateTime;

        // ����Ѿ��ڴ�������Ҫ����
        if(missionHour== HoursType.��ʱ|| missionHour == HoursType.��ʱ|| missionHour == HoursType.��ʱ)
        {
            double dis = System.Math.Sqrt(System.Math.Pow((player.transform.position.x - missionLocation.x), 2) + System.Math.Pow((player.transform.position.z - missionLocation.z), 2));
            Debug.Log("������ " + dis);
            if (dis <= 0.5)
            {
                isEntered = true;
                disNowMissionOperateTime();
                Debug.Log("�Ѿ��ڴ���");
            }
        }
    }
    
    private void updateStage()
    {
        missionLocation = missionList[nowMissionIndex].missionTransform.position;
        double dis = System.Math.Sqrt(System.Math.Pow((player.transform.position.x - missionLocation.x), 2) + System.Math.Pow((player.transform.position.z - missionLocation.z), 2));
        // ��������ص㣬��ʾ��ʾ�����֣�����·�꣬���õ�ǰ�׶Σ����ؼ�ͷ
        //Debug.Log("���� "+dis);
        if (dis <= 3)
        {
            // ���û���������������ʾstartHint��ʾ
            if (isEntered == false)
                showHint(missionList[nowMissionIndex].startHint);
            //_LineRenderer.SetActive(false);
            isEntered = true;
            _LineRenderer.enabled = false;
            player.transform.Find("Leader").gameObject.SetActive(false);
            player.GetComponent<NavMeshAgent>().Stop();

            // �����ɢ���򵽴�ص���������
            if(missionHour == HoursType.��ʱ && nowMissionIndex == 1)
            {
                disNowMissionOperateTime();
            }
        }
        // ��ʾ·��
        else
        {
            _LineRenderer.enabled = true;
        }
        

        // ִ�й�����Ӧ�Ĵ���,ִ����һ������, ͬʱ�ж������Ƿ����
        if (nowMissionOperateTime == 0)
        {
            if (nowMissionIndex + 1 < missionList.Count)
            {
                isEntered = false;
                showHint(missionList[nowMissionIndex].endHint);
                nowMissionIndex++;
                nowMissionOperateTime = missionList[nowMissionIndex].operateTime;
                player.GetComponent<NavMeshAgent>().Resume();
                player.transform.Find("Leader").gameObject.SetActive(true);
                updatePlayerCanvasMissions();
            }
            // �����б���� ���һ������ִ����
            else
            {
                Debug.Log("�������");
                player.transform.Find("Leader").gameObject.SetActive(false);
                player.GetComponent<NavMeshAgent>().Stop();
                _LineRenderer.enabled = false;
                isTriggedMission = false;
                showHint(missionList[nowMissionIndex].endHint);
                Invoke("showEndHint", 3f);
            }
        }
    }

    private void showEndHint()
    {
        showHint("������а�ť�Լ���ʱ����ת");
    }

    public void showHint(string str)
    {
        CancelInvoke();

        // ������ʾ���ı�
        //Debug.Log(str);
        playerCanvas.transform.Find("HintPanel/hintText").GetComponent<TextMeshProUGUI>().text = str;
        playerCanvas.transform.Find("HintPanel/hintText").GetComponent<TextMeshProUGUI>().alpha = 1.0f;

        playerCanvas.transform.Find("HintPanel").gameObject.SetActive(true);
        // ����3.0s������
        //playerCanvas.transform.Find("HintPanel").SetActive(false);
        InvokeRepeating("hideHint", 3.0f, 0.1f);
    }
    private void hideHint()
    {
        playerCanvas.transform.Find("HintPanel/hintText").GetComponent<TextMeshProUGUI>().alpha -= 0.05f;
        if (playerCanvas.transform.Find("HintPanel/hintText").GetComponent<TextMeshProUGUI>().alpha <= 0f)
        {
            //Debug.Log(playerCanvas.transform.Find("HintPanel/hintText").GetComponent<TextMeshProUGUI>().alpha);
            playerCanvas.transform.Find("HintPanel").gameObject.SetActive(false);
            CancelInvoke();
        }
    }
    public void disNowMissionOperateTime()
    {
        // ����ִ�������ҵ����������
        if (isEntered == true && isTriggedMission == true)
        {
            nowMissionOperateTime--;
        }
    }

    // ����������ʱ����ʱ����ʱ������(�������⼸��ʱ���û�������˯��)
    public void resetSleep()
    {
        Debug.Log("����˯��");
        nowMissionOperateTime = 1;
        player.GetComponent<NavMeshAgent>().Resume();
        _LineRenderer.enabled = true;
        isTriggedMission = true;
    }

    public HoursMissionTrigger.HoursType getMissionHour()
    {
        return missionHour;
    }

    public int getMissionIndex()
    {
        return nowMissionIndex;
    }

    public bool getIstriggeredMission()
    {
        return isTriggedMission;
    }

    public bool isEndMission()
    {
        if (nowMissionIndex >= missionList.Count - 1)
        {
            return true;
        }
        return false;
    }
    public void resetNowMissionIndex()
    {
        nowMissionIndex = -5;
        hideHint();
    }
    
    public void deleteMissionList()
    {
        foreach (GameObject mission in missionTextList)
        {
            Destroy(mission);
        }
        missionTextList.Clear();
        missionList.Clear();
    }

}