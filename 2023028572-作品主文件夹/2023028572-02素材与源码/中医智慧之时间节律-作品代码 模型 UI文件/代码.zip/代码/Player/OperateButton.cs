﻿using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class OperateButton : MonoBehaviour,IPointerClickHandler
{
    public Canvas operateCanvas;
    public Canvas playerCanvas;
    public GameObject player; 
    public GameObject foodItemPrefab; 

    private Dictionary<string, GameObject> foodItems = new Dictionary<string, GameObject>();     // 锟斤拷锟斤拷时锟斤拷锟斤拷foodItem预锟狡硷拷 实锟斤拷
    private Dictionary<string, int> foodsNum = new Dictionary<string, int>();
    private GameObject collidingObj;
    private string collidingObjType;
    private GameObject interactPanel;

    public void OnPointerClick(PointerEventData eventData)
    {
        
        // 锟斤拷食锟斤拷锟斤拷锟?
        if (collidingObjType == "Food")
        {
            player.GetComponent<Animator>().SetTrigger("operateTrigger");
            player.GetComponent<MissionHandler>().disNowMissionOperateTime();

            FoodAttributes foodAttribute = collidingObj.GetComponent<FoodAttributes>();
            // 锟斤拷没锟叫革拷锟斤拷锟藉，锟津创斤拷一锟斤拷fooditem锟斤拷锟斤拷 playerCanvas
            if (!foodItems.ContainsKey(foodAttribute.foodName))
            {
                GameObject foodItem = Instantiate(foodItemPrefab);
                foodItems.Add(foodAttribute.foodName, foodItem);
                foodsNum.Add(foodAttribute.foodName, foodAttribute.addNum);
                foodItem.transform.parent = playerCanvas.transform;
                foodItem.transform.position = new Vector3(foodItems.Count*140+100,1000,0);
                foodItem.transform.Find("foodText").GetComponent<TextMeshProUGUI>().text
                    = foodsNum[foodAttribute.foodName] == 1 ? foodAttribute.foodName : foodAttribute.foodName + ":" + foodsNum[foodAttribute.foodName];
                Debug.Log(foodItem.transform.position);
                foodItem.transform.Find("foodImage").GetComponent<Image>().sprite = foodAttribute.foodImage;

            }
            // 锟斤拷锟斤拷锟叫革拷锟斤拷锟藉，锟斤拷锟斤拷+addNum
            else
            {
                GameObject foodItem = foodItems[foodAttribute.foodName];
                foodsNum[foodAttribute.foodName] += foodAttribute.addNum;
                foodItem.transform.Find("foodText").GetComponent<TextMeshProUGUI>().text
                                   = foodsNum[foodAttribute.foodName] == 1 ? foodAttribute.foodName : foodAttribute.foodName + ":" + foodsNum[foodAttribute.foodName];
            }
        }
        // 锟斤拷要锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟?
        if (collidingObjType == "Anban")
        {
            player.GetComponent<Animator>().SetTrigger("operateTrigger");
            player.GetComponent<MissionHandler>().disNowMissionOperateTime();

            //Debug.Log(collidingObjType);
            AnbanAttribute anbanAttribute = collidingObj.GetComponent<AnbanAttribute>();
            IntroductionAttribute.SeasonsType missionSeason = player.GetComponent<MissionHandler>().getMissionSeason();
            GameObject panelPrefab;
            //Debug.Log("aaa  " + anbanAttribute.panelPrefabDict.Count);

            if (anbanAttribute.panelPrefabDict.ContainsKey(missionSeason))
            {
                panelPrefab = anbanAttribute.panelPrefabDict[missionSeason];

                foreach (var item in anbanAttribute.panelPrefabDict)
                {
                    item.Value.SetActive(false);
                }
                panelPrefab.SetActive(true);
              
                //GameObject interactPanel = Instantiate(panelPrefab);
                //interactPanel.transform.parent = operateCanvas.transform.Find("交互操作");
                //interactPanel.transform.localPosition = new Vector3(0, 0, 0);
                operateCanvas.transform.Find("人物操作").gameObject.SetActive(false);
                operateCanvas.transform.Find("交互操作").gameObject.SetActive(true);
            }
        }

        if (collidingObjType == "HoursObject")
        {
            collidingObj.GetComponent<HoursObjectAttribute>().onOperate();
        }
        
        if(collidingObjType == "SeasonObject")
        {
            collidingObj.GetComponent<SeasonObjectAttribute>().onOperate();
        }

    }

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        //plumText.text = plumNum.ToString();
        //CandyText.text = CandyNum.ToString();
        collidingObjType = CollidingObjects.collidingObjectType;
        collidingObj = CollidingObjects.collidingObject;

        // 锟斤拷锟矫伙拷锟斤拷锟斤拷锟斤拷锟斤拷澹?锟津将诧拷锟斤拷锟斤拷钮锟斤拷为锟斤拷色
        if (CollidingObjects.collidingObject == null)
        {
            Color color = Color.gray;
            this.GetComponent<Image>().color = color;
        }
        else
        {
            Color color = Color.white;
            this.GetComponent<Image>().color = color;
        }
    }
}
