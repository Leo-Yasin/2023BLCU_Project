using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using UnityEngine.UIElements;
using UnityEngine.Windows;
using Input = UnityEngine.Input;

public class PlayerManager : MonoBehaviour
{
    private float w, a, s, d, x, y, yRot, g, up, gravity;
    public float moveSpeed, rotateSpeed, upSpeed;
    private CharacterController cc;
    public GameObject myCamera;
    private bool isGround;
    private Animator animator;
    public Transform headTF;
    public Joystick moveStick;

    private float moveSpeed_Rem, rotateSpeed_Rem, upSpeed_Rem;

    public static PlayerManager Instance;
    // Start is called before the first frame update
    void Start()
    {
        moveSpeed_Rem = moveSpeed;
        rotateSpeed_Rem = rotateSpeed;
        upSpeed_Rem = upSpeed;

        Instance = this;
        yRot = 0;
        cc = this.GetComponent<CharacterController>();
        gravity = 9.8f;
        animator = this.GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        Move();

    }

    private void Move()
    {
        animator.SetInteger("Speed", 0);
        animator.SetInteger("Dir", 0);
        w = d = a = s = x = y = 0;
        if (cc.collisionFlags == CollisionFlags.Below)
        {
            isGround = true;
        }
        else
        {
            isGround = false;
        }
        w = moveStick.Vertical;
        a = moveStick.Horizontal;
        // ��Ծ
        if (Input.GetKey(KeyCode.Space) && isGround)
        {
            up = upSpeed;
        }
        if (w != 0 || a != 0 || s != 0 || d != 0)
        {
            animator.SetInteger("Speed", 1);
            if (a + d < -0.5 && w + s >0.5) animator.SetInteger("Dir", 1);
            if (a + d > 0.5 && w + s > 0.5) animator.SetInteger("Dir", 2);
            if (a + d < -0.5 && w + s < -0.5) animator.SetInteger("Dir", 3);
            if (a + d > 0.5 && w + s < -0.5) animator.SetInteger("Dir", 4);
            if (w + s < -0.8) animator.SetInteger("Dir", 5);

            //Debug.Log(a + d + "aaa" + w + s);
        }
        if (up > 0)
        {
            animator.SetInteger("Speed", 3);

        }
        //Debug.Log((w + s) + " " + (a + d));
        up -= gravity * Time.deltaTime;
        up = Mathf.Max(-50, up);
        cc.Move(this.transform.right * (a + d) * Time.deltaTime * moveSpeed + this.transform.forward *
            (w + s) * Time.deltaTime * moveSpeed + this.transform.up * up * upSpeed * Time.deltaTime);
    }

    public void stopPlayer()
    {    
        moveSpeed = 0;
        rotateSpeed = 0;
        upSpeed = 0;
    }

public void resumePlayer()
    {
        moveSpeed = moveSpeed_Rem;
        rotateSpeed = rotateSpeed_Rem;
        upSpeed = upSpeed_Rem;
    }
}
