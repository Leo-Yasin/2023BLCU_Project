using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraAvoidBlock : MonoBehaviour
{

    public Transform player_Transform;//��ҽ�ɫ

    private List<GameObject> collideredObjects;//��������hit����GameObject
    private List<GameObject> bufferOfCollideredObjects;//�ϴ�����hit����GameObject

    void Start()
    {
        collideredObjects = new List<GameObject>();
        bufferOfCollideredObjects = new List<GameObject>();
    }

    // Update is called once per frame
    void Update()
    {
        bufferOfCollideredObjects.Clear();
        for (int temp = 0; temp < collideredObjects.Count; temp++)
        {
            bufferOfCollideredObjects.Add(collideredObjects[temp]);//�õ��ϴε�
        }
        collideredObjects.Clear();

        //��������
        Vector3 dir = -(player_Transform.position - transform.position).normalized;
        RaycastHit[] hits;
        hits = Physics.RaycastAll(player_Transform.position, dir, Vector3.Distance(player_Transform.position, transform.position));
        Debug.DrawLine(player_Transform.position, transform.position, Color.red);//������ʾ�Ա�۲�

        for (int i = 0; i < hits.Length; i++)
        {
            if (hits[i].collider.gameObject.name != "Plane" && hits[i].collider.gameObject.name != "Cube")
            {
                collideredObjects.Add(hits[i].collider.gameObject);//�õ����ڵ�
            }
        }
        //���ϴεĻ�ԭ����ε�͸��
        for (int i = 0; i < bufferOfCollideredObjects.Count; i++)
        {
            Debug.Log(bufferOfCollideredObjects[i].GetComponent<Renderer>());
            if(bufferOfCollideredObjects[i].GetComponent<Renderer>()!= null)
                SetMaterialsColor(bufferOfCollideredObjects[i].GetComponent<Renderer>(), false);
        }
        for (int i = 0; i < collideredObjects.Count; i++)
        {
            Debug.Log(collideredObjects[i].GetComponent<Renderer>());
            if (collideredObjects[i].GetComponent<Renderer>() != null)
                SetMaterialsColor(collideredObjects[i].GetComponent<Renderer>(), true);
        }
    }

    //�Ƿ��͸��
    void SetMaterialsColor(Renderer r, bool isClear)
    {
        if (isClear)
        {
            int materialsNumber = r.sharedMaterials.Length;
            for (int i = 0; i < materialsNumber; i++)
            {
                r.materials[i].shader = Shader.Find("Transparent/Diffuse");
                Color tempColor = r.materials[i].color;
                tempColor.a = 0.4f;
                r.materials[i].color = tempColor;

            }
        }
        else
        {
            int materialsNumber = r.sharedMaterials.Length;
            for (int i = 0; i < materialsNumber; i++)
            {
                r.materials[i].shader = Shader.Find("Transparent/Diffuse");
                Color tempColor = r.materials[i].color;
                tempColor.a = 1f;
                r.materials[i].color = tempColor;

            }
        }
    }
}