using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using TMPro;
using UnityEngine.UIElements;

public class MissionHandler : MonoBehaviour
{
    public GameObject lineRendererObject;
    public GameObject player;
    public GameObject playerCanvas;
    public GameObject missionPrefab;

    private int nowMissionOperateTime; // 当前任务需要进行几次操作


    private NavMeshAgent _Nav;
    private LineRenderer _LineRenderer;
    private int nowMissionIndex;

    private List<IntroductionAttribute.Mission> missionList;
    private List<GameObject> missionTextList;
    private IntroductionAttribute.SeasonsType missionSeason;
    private bool isEntered; // 是否到达过当前任务区域
    private bool isTriggedMission;
    private Vector3 lastTargetPos;
    // Use this for initialization
    void Start()
    {
        _Nav = player.transform.GetComponent<NavMeshAgent>();
        _LineRenderer = lineRendererObject.transform.GetComponent<LineRenderer>();
        _LineRenderer.SetWidth(0.1f, 0.1f);
        _LineRenderer.SetColors(Color.blue, Color.green);
        isTriggedMission = false;
        lastTargetPos = Vector3.zero;
    }

    // Update is called once per frame
    [System.Obsolete]
    void Update()
    {
        // 触发了任务才开始执行
        if (isTriggedMission == true)
        {
            updateStage();
            Vector3 missionLocation = missionList[nowMissionIndex].missionTransform.position;
            drawLeadArrow(missionLocation);
        }
            
    }
    
    // 更新任务列表 颜色
    private void updatePlayerCanvasMissions()
    {
        foreach (GameObject mission in missionTextList)
        {
            mission.GetComponent<TextMeshProUGUI>().color = Color.white;
        }
        missionTextList[nowMissionIndex].GetComponent<TextMeshProUGUI>().color = new Color(1.0f, 0.76f, 0.294f);
    }

    // 绘制导航箭头
    [System.Obsolete]
    private void drawLeadArrow(Vector3 targetPoint)
    {
        
        //  进入过任务区域，则不引路
        if (isEntered == true) { return; }
        if (lastTargetPos != targetPoint)
        {
            lastTargetPos = targetPoint;
            _Nav.SetDestination(targetPoint);        //NavMeshAgent自带移动方法  

        }
        if (_Nav.path.corners.Length > 1)                  //时刻检测路线的点，当大于1的时候，把这些点赋予给LineRenderer来绘制出线条
        {
            // 控制箭头朝向
            //Debug.Log(_Nav.path.corners[1]);
            player.transform.Find("Leader").transform.LookAt(_Nav.path.corners[1]);

            // 绘制路线
            //_LineRenderer.SetVertexCount(_Nav.path.corners.Length);
            //int count = 2;
            //Vector3[] road = new Vector3[count];
            //for (int i = 0; i < count; i++)
            //{
            //    road[i] = _Nav.path.corners[i];
            //}
            //_LineRenderer.SetVertexCount(count);
            //_LineRenderer.SetPositions(road);
        }
    }

    // 更新任务列表，并开始执行任务
    public void updateMissionList(List<IntroductionAttribute.Mission> missionList, IntroductionAttribute.SeasonsType missionSeason)
    {
        this.missionTextList = new List<GameObject>();
        this.missionList = new List<IntroductionAttribute.Mission>(missionList);
        this.missionSeason = missionSeason;
        int index = 0;
        foreach (IntroductionAttribute.Mission mission in missionList)
        {
            GameObject missionText = Instantiate(missionPrefab);
            missionTextList.Add(missionText);
            missionText.transform.SetParent(playerCanvas.transform.Find("MissionPanel"));
            missionText.transform.localPosition = new Vector3(0, -50 * index, 0);
            index++;
            missionText.GetComponent<TextMeshProUGUI>().text = mission.missionDescribe;
        }
        nowMissionIndex = 0;
        missionTextList[nowMissionIndex].GetComponent<TextMeshProUGUI>().color = new Color(1.0f,0.76f,0.294f);

        // 开始执行任务
        isTriggedMission = true;
        isEntered = false;
        nowMissionOperateTime = missionList[nowMissionIndex].operateTime;
        player.transform.Find("Leader").gameObject.SetActive(true);
    }

    // 更新任务阶段
    [System.Obsolete]
    private void updateStage()
    {
        Vector3 missionLocation = missionList[nowMissionIndex].missionTransform.position;
        double dis = System.Math.Sqrt(System.Math.Pow((player.transform.position.x - missionLocation.x), 2) + System.Math.Pow((player.transform.position.z - missionLocation.z), 2));
        // 到达任务地点，显示提示性文字，隐藏路标，设置当前阶段，隐藏箭头
        if (dis <= 3.0)
        {
            // 如果没到达过该区域，则显示startHint提示
            if(isEntered == false)
                showHint(missionList[nowMissionIndex].startHint);
            //_LineRenderer.SetActive(false);
            isEntered = true;
            _LineRenderer.enabled = false;
            player.transform.Find("Leader").gameObject.SetActive(false);
            player.GetComponent<NavMeshAgent>().Stop();
        }
        // 显示路标
        else
        {
            _LineRenderer.enabled = true;
        }

        // 执行过了相应的次数,执行下一个任务, 同时判断任务是否结束
        if (nowMissionOperateTime == 0)
        {
            if (nowMissionIndex + 1 < missionList.Count)
            {
                isEntered = false;
                showHint(missionList[nowMissionIndex].endHint);
                nowMissionIndex++;
                nowMissionOperateTime = missionList[nowMissionIndex].operateTime;
                player.GetComponent<NavMeshAgent>().Resume();
                player.transform.Find("Leader").gameObject.SetActive(true);
                updatePlayerCanvasMissions();
            }
            // 任务列表清空
            else
            {
                isTriggedMission = false;
                _LineRenderer.enabled = false;
                player.transform.Find("Leader").gameObject.SetActive(false);
                player.GetComponent<NavMeshAgent>().Stop();
                showHint(missionList[nowMissionIndex].endHint);
            }
        } 
    }

    private void showHint(string str)
    {
        CancelInvoke();

        // 设置提示性文本
        //Debug.Log(str);
        playerCanvas.transform.Find("HintPanel/hintText").GetComponent<TextMeshProUGUI>().text = str;
        playerCanvas.transform.Find("HintPanel/hintText").GetComponent<TextMeshProUGUI>().alpha = 1.0f;

        playerCanvas.transform.Find("HintPanel").gameObject.SetActive(true);
        // 控制3.0s后隐藏
        //playerCanvas.transform.Find("HintPanel").SetActive(false);
        InvokeRepeating("hideHint", 3.0f, 0.1f);
    }
    private void hideHint()
    {
        playerCanvas.transform.Find("HintPanel/hintText").GetComponent<TextMeshProUGUI>().alpha -= 0.05f;
        if (playerCanvas.transform.Find("HintPanel/hintText").GetComponent<TextMeshProUGUI>().alpha <= 0f)
        {
            Debug.Log(playerCanvas.transform.Find("HintPanel/hintText").GetComponent<TextMeshProUGUI>().alpha);
            playerCanvas.transform.Find("HintPanel").gameObject.SetActive(false);
            CancelInvoke();
        }
    }

    public void disNowMissionOperateTime()
    {
        // 正在执行任务，且到达过该区域
        //Debug.Log("disNow");
        if (isEntered == true)
            nowMissionOperateTime--;
    }

    public IntroductionAttribute.SeasonsType getMissionSeason()
    {
        return missionSeason;
    }

    public bool getIstriggeredMission()
    {
        return isTriggedMission;
    }

    public bool isEndMission()
    {
        if (nowMissionIndex == missionList.Count - 1)
        {
            return true;
        }
        return false;
    }
}