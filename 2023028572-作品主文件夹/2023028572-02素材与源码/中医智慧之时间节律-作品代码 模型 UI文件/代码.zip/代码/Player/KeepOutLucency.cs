using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeepOutLucency : MonoBehaviour
{
    public Transform tar;
    public List<Renderer> listLastRend = new List<Renderer>();
    public List<MeshRenderer> listMeshRenderer = new List<MeshRenderer>();
    void Update()
    {
        if (tar != null)
        {
            for (int i = 0; i < listLastRend.Count; i++)
            {
                TransparencySet(listLastRend[i], 1.0f);
            }
            for (int i = 0; i < listMeshRenderer.Count; i++)
            {
                TransparencySet(listMeshRenderer[i], 1.0f);
            }
            listLastRend.Clear();
            listMeshRenderer.Clear();
            Vector3 tarDir = (tar.position - transform.position).normalized;
            Debug.DrawLine(tar.position, transform.position, Color.red);
            float tarDis = Vector3.Distance(tar.position, transform.position);
            RaycastHit[] listHitObj = Physics.RaycastAll(transform.position, tarDir, tarDis);
            Debug.Log(listHitObj.Length);
            for (int i = 0; i < listHitObj.Length; i++)
            {
                Debug.Log(listHitObj[i].collider.name);
                RaycastHit hit = listHitObj[i];
                if (hit.transform == tar.transform)
                {
                    continue;
                }
                Renderer renderer = hit.collider.GetComponent<Renderer>();

                if (renderer)
                {
                    listLastRend.Add(renderer);
                    TransparencySet(renderer, 0.3f);
                }
                else
                {
                    MeshRenderer meshRenderer = hit.collider.GetComponent<MeshRenderer>();
                    if (meshRenderer != null)
                    {
                        listMeshRenderer.Add(meshRenderer);
                        TransparencySet(meshRenderer, 0.3f);
                    }
                }
            }
        }
    }
    void TransparencySet(Renderer renderer, float a)
    {
        renderer.material.shader = Shader.Find("Transparent/Diffuse");
        renderer.material.color = new Color(renderer.material.color.r, renderer.material.color.g, renderer.material.color.b, a);
    }

    void TransparencySet(MeshRenderer renderer, float a)
    {
        renderer.material.shader = Shader.Find("Transparent/Diffuse");
        renderer.material.color = new Color(renderer.material.color.r, renderer.material.color.g, renderer.material.color.b, a);
    }
}

