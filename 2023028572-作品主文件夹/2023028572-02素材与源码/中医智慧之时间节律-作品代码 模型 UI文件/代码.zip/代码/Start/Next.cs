using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Next : MonoBehaviour
{
    public GameObject intor1;
    public GameObject intor2;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void onbtnCilck()
    {

        intor1.SetActive(false);
        intor2.SetActive(true);
        // Debug.Log("WalkAttribute");
    }
}
